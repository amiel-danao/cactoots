package com.ameclix.dexterpizza.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.ameclix.dexterpizza.MainActivity;
import com.ameclix.dexterpizza.R;
import com.ameclix.dexterpizza.data.model.CartItem;
import com.ameclix.dexterpizza.data.model.Food;
import com.ameclix.dexterpizza.ui.cart.CartFragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CartItemAdapter extends ArrayAdapter<CartItem> {
    private CartFragment cartFragment;
    private ArrayList<CartItem> theSavedCartItems;
    public final String TAG = "myLogTag";
    //private int totalCartPrice;
    public HashMap<String, Integer> placedCartPrices;
    public HashMap<String, CheckBox> cartItemCheckBoxes;

    public CartItemAdapter(@NonNull Context context, ArrayList<CartItem> cart_items, CartFragment cartFragment) {
        super(context, 0, cart_items);
        this.cartFragment = cartFragment;
        this.theSavedCartItems = cart_items;
        this.placedCartPrices = new HashMap<>();
        this.cartItemCheckBoxes = new HashMap<>();
    }
//
//    public ArrayList<CartItem> getValues()
//    {
//        return theSavedCartItems;
//    }
    private class ViewHolder {

        protected CheckBox checkBox;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //return super.getView(position, convertView, parent);
        final ViewHolder holder;
        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(MainActivity.context).inflate(R.layout.cart_item_entry, parent, false);
            holder.checkBox = (CheckBox) convertView.findViewById(R.id.cart_item_check_box);
            convertView.setTag(holder);
//            holder.checkBox.setChecked(true);
//            holder.checkBox.jumpDrawablesToCurrentState();

        }
        else {
            // The getTag returns the viewHolder object set as a tag to the view
            holder = (ViewHolder)convertView.getTag();


        }

        final CartItem thisCartItem = getItem(position);

        //get all reference ids
        TextView cart_item_name = convertView.findViewById(R.id.cart_item_name);
        TextView cart_item_qtys = convertView.findViewById(R.id.cart_item_qtys);
        final TextView cart_item_price = convertView.findViewById(R.id.cart_item_price);
        ImageView cart_remove_button = convertView.findViewById(R.id.delete_cart_item_button);
        final ImageView cart_item_image = convertView.findViewById(R.id.cart_item_image);
        ImageView img_edit_cart_button = convertView.findViewById(R.id.img_edit_cart_button);

        //set info on this particular cart item
        cart_item_name.setText(thisCartItem.item_name);

        String qty_text = "x"+thisCartItem.myQtys.qty1 + " small";
        if(thisCartItem.myQtys.qty2 > 0)
            qty_text += ", x" + thisCartItem.myQtys.qty2 + " medium";
        if(thisCartItem.myQtys.qty3 > 0)
            qty_text += ", x" + thisCartItem.myQtys.qty3 + " large";

        cart_item_qtys.setText(qty_text);

        cart_remove_button.setTag(thisCartItem);
        if(!cart_remove_button.hasOnClickListeners())
            cart_remove_button.setOnClickListener(removeCartItemlistener);


        img_edit_cart_button.setTag(thisCartItem);
        if(!img_edit_cart_button.hasOnClickListeners())
            img_edit_cart_button.setOnClickListener(editCartItemlistener);


        //set to default image first
        Drawable d = MainActivity.context.getResources().getDrawable(R.drawable.dexter_pizza_logo);
        cart_item_image.setImageDrawable(d);

        //Log.d(TAG, thisCartItem.getItem_id());

        //holder.checkBox.setText("Checkbox " + position);
        //holder.tvAnimal.setText(checks.get(position).getAnimal());


        holder.checkBox.setChecked(cartFragment.checks.get(position));

        //holder.checkBox.setTag(R.integer.btnplusview, convertView);
        holder.checkBox.setTag(position);
        holder.checkBox.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Integer pos = (Integer)  holder.checkBox.getTag();
               //Toast.makeText(MainActivity.context, "Checkbox " + pos + " clicked!", Toast.LENGTH_SHORT).show();

               if (cartFragment.checks.get(pos)){
                   cartFragment.checks.set(pos, false);
                   if(cartFragment.checked_items_id.contains(thisCartItem.getItem_id()))
                   {
                       cartFragment.checked_items_id.remove(thisCartItem.getItem_id());
                   }
               }
               else {
                   cartFragment.checks.set(pos, true);
                   if(!cartFragment.checked_items_id.contains(thisCartItem.getItem_id()))
                       cartFragment.checked_items_id.add(thisCartItem.getItem_id());
               }


               cartFragment.setTotalCartPrice(getTotalCartPrices());
           }
       });


        Food food_ref = MainActivity.foodByName.get(thisCartItem.getItem_id());


        if(food_ref != null) {
            Food food = MainActivity.instance.getFoodInfo(food_ref.category, food_ref.uid);

            String string_image = food.getImage();

            if (string_image.trim().length() > 0) {
                byte[] decodedString = Base64.decode(string_image, Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                cart_item_image.setImageBitmap(decodedByte);
            }
            else
            {
                Log.d(TAG, "cart item no image");
            }




            int total = (thisCartItem.myQtys.qty1 * food.price1) + (thisCartItem.myQtys.qty2 * food.price2) + (thisCartItem.myQtys.qty3 * food.price3);
            Log.d(TAG, "total : " + total);
            cart_item_price.setText("₱" + total);

//            if(!placedCartPrices.containsKey(food.uid))
//            {
                //totalCartPrice += total;
                placedCartPrices.put(food.uid, total);
                cartFragment.setTotalCartPrice(getTotalCartPrices());
//            }
        }
        else
        {
            Log.d(TAG, "Food is null!");
        }

        cartItemCheckBoxes.put(thisCartItem.getItem_id(), holder.checkBox);
        notifyDataSetChanged();


        return convertView;
    }



//    public List<String> getAllCheckedCartItems()
//    {
//        List<String> retVal = new ArrayList<>();
//        for (String str: cartFragment.checks) {
//            if(cartItemCheckBoxes.get(str).isChecked())
//                retVal.add(str);
//        }
//
//        return retVal;
//    }

    //get total price of all checkboxes only!
    public int getTotalCartPrices()
    {
        int retVal = 0;

//        for (int i=0; i< cartFragment.arrayOfCartItems.size(); i++) {
//            String key =cartFragment.arrayOfCartItems.get(i).getItem_id();
//            if(cartItemCheckBoxes.containsKey(key)) {
//                if (cartItemCheckBoxes.get(key).isChecked())
//                    retVal += placedCartPrices.get(key);
//            }
//        }

        for (int i=0; i< cartFragment.checked_items_id.size(); i++) {
            String key = cartFragment.checked_items_id.get(i);
            if(placedCartPrices.containsKey(key))
                retVal += placedCartPrices.get(key);
        }

//        Log.d(TAG, "Total = " + retVal);
//        List<String> checked = getAllCheckedCartItems();
//        Log.d(TAG, "Total checked = " + checked.size());
        cartFragment.checkOutPrice = retVal;
        return retVal;
    }


    final View.OnClickListener editCartItemlistener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            CartItem selected_cart_item = (CartItem) view.getTag();

            cartFragment.showICartItemEditDialog("Item quantities", selected_cart_item, "Update", "Cancel");

        }
    };

    //confirm remove item from cart
    final View.OnClickListener removeCartItemlistener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            final CartItem selected_cart_item = (CartItem) view.getTag();


            cartFragment.builder = new AlertDialog.Builder(MainActivity.context).setCancelable(false);

            cartFragment.alert = cartFragment.builder.setMessage("Are you sure you want to remove " + selected_cart_item.item_name + " to your cart?").setTitle("Confirm remove item").setPositiveButton("Yes", null)
                    .setNegativeButton("No", null).create();

            cartFragment.alert.setCanceledOnTouchOutside(false);

            //override dismiss
            cartFragment.alert.setOnShowListener(new DialogInterface.OnShowListener() {

                @Override
                public void onShow(DialogInterface dialogInterface) {

                    final Button positiveButton = cartFragment.alert.getButton(AlertDialog.BUTTON_POSITIVE);
                    final Button negativeButton = cartFragment.alert.getButton(AlertDialog.BUTTON_NEGATIVE);

                    positiveButton.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            final FirebaseDatabase database = FirebaseDatabase.getInstance();
                            final DatabaseReference myRef = database.getReference("users/"+ MainActivity.loggedUser.getUserId() + "/cart/" + selected_cart_item.getItem_id());

                            myRef.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    Toast.makeText(
                                            MainActivity.context, selected_cart_item.item_name + " successfully removed", Toast.LENGTH_LONG).show();
                                    //expandableListDetail.get(selected_category).remove(selectedFood);
                                    placedCartPrices.remove(selected_cart_item.getItem_id());

                                    int pos = cartFragment.arrayOfCartItems.indexOf(selected_cart_item);
                                    cartItemCheckBoxes.remove(selected_cart_item);
                                    cartFragment.checks.remove(pos);
                                    cartFragment.arrayOfCartItems.remove(selected_cart_item);




                                    notifyDataSetChanged();
                                    cartFragment.alert.dismiss();
                                }
                            });
                        }
                    });
                }
            });

            cartFragment.alert.show();

        }
    };


    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        cartFragment.total_cart_items.setText("" + cartFragment.arrayOfCartItems.size());
        cartFragment.setTotalCartPrice(getTotalCartPrices());
    }
}