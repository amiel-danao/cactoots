package com.ameclix.dexterpizza.ui.orders;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.ameclix.dexterpizza.MainActivity;
import com.ameclix.dexterpizza.R;
import com.ameclix.dexterpizza.adapters.OrderAdapter;
import com.ameclix.dexterpizza.data.model.Food;
import com.ameclix.dexterpizza.data.model.Order;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class OrdersFragment extends Fragment {

    public final String TAG = "myLogTag";
    private ConstraintLayout loadingProgressBar;
    public static ArrayList<Order> cached_orders = new ArrayList<>();
    public ArrayList<Order> filtered_orders = new ArrayList<>();
    private ListView orders_listview;
    public OrderAdapter orderAdapter;
    public LayoutInflater inflater;
    public String[] orderStateStrings = {"Pending", "On Process", "On Delivery", "Delivered"};

    public Context context;
    private Spinner process_spinner;

    public static OrdersFragment instance;

    public Order orderToProcessed;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
//        ordersViewModel =
//                ViewModelProviders.of(this).get(OrdersViewModel.class);
        View root = inflater.inflate(R.layout.fragment_orders, container, false);

        instance = this;

        final ImageView bg = root.findViewById(R.id.process_bg);
        loadingProgressBar = root.findViewById(R.id.loading_constraint);
        orders_listview = root.findViewById(R.id.orders_listview);
        orderAdapter = new OrderAdapter(MainActivity.context, filtered_orders, this);
        orders_listview.setAdapter(orderAdapter);
        context = getContext();

        loadMyOrdersFromDB();

        process_spinner = root.findViewById(R.id.process_spinner);

        process_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                Drawable d = MainActivity.context.getResources().getDrawable(R.drawable.order_bg1);
                switch (position)
                {
                    case 0 : d = MainActivity.context.getResources().getDrawable(R.drawable.order_bg1); setOrderFilter(0); bg.setBackgroundResource(R.color.order_bg1);break;
                    case 1 : d = MainActivity.context.getResources().getDrawable(R.drawable.order_bg2); setOrderFilter(1); bg.setBackgroundResource(R.color.order_bg2);break;
                    case 2 : d = MainActivity.context.getResources().getDrawable(R.drawable.order_bg3); setOrderFilter(2); bg.setBackgroundResource(R.color.order_bg3);break;
                    case 3 : d = MainActivity.context.getResources().getDrawable(R.drawable.order_bg4); setOrderFilter(3); bg.setBackgroundResource(R.color.order_bg4);break;
                }


                bg.setImageDrawable(d);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        this.inflater = inflater;
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "Activity Resume!");
        if(orderToProcessed != null) {
            filtered_orders.clear();
            orderAdapter.clear();
            orderAdapter.notifyDataSetChanged();

            removeCachedOrder(orderToProcessed.getUid());

            cached_orders.add(orderToProcessed);
            Log.d(TAG, "Re added : " + orderToProcessed.orderNumber);
            orderToProcessed = null;
        }
        setOrderFilter(process_spinner.getSelectedItemPosition());
    }

    public void removeCachedOrder(String uid)
    {
        Order orderToRemove = null;
        for (Order order: cached_orders) {
            if(order.getUid().equals(uid)) {
                orderToRemove = order;
                break;
            }
        }
        cached_orders.remove(orderToRemove);
    }

//    public void removeFilterOrder(Order toBeRemoved)
//    {
////        if(filtered_orders.contains(toBeRemoved))
////            filtered_orders.remove(toBeRemoved);
//        //showToast("Removed!");
////        orderAdapter.notifyDataSetChanged();
//        Log.d(TAG, toBeRemoved.state + " state");
//    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        // Note: getValues() is a method in your ArrayAdapter subclass
        
        super.onSaveInstanceState(outState);        
    }

    private void loadMyOrdersFromDB()
    {
        cached_orders.clear();
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        showLoading(true);
        if(MainActivity.isAdmin)
        {
            database.getReference("orders").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot orders) {
                    if (orders.exists()) {
                        int i = 0;
                        for (DataSnapshot myOrder : orders.getChildren()) {

                            Order thisOrder = myOrder.getValue(Order.class);
                            thisOrder.setUid(myOrder.getKey());
                            cached_orders.add(thisOrder);
                            i++;
                            if (i >= orders.getChildrenCount()) {
                                Log.d(TAG, "All orders count : " + i);
                                setOrderFilter(process_spinner.getSelectedItemPosition());
                                showLoading(false);
                            }
                        }
                    } else {
                        showToast("No orders!");
                        showLoading(false);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
        else {

            database.getReference("orders").orderByChild("person_uid").equalTo(MainActivity.loggedUser.getUserId()).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot orders) {
                    if (orders.exists()) {
                        int i = 0;
                        for (DataSnapshot myOrder : orders.getChildren()) {
                            //Log.d(TAG,myOrder.getValue(String.class));
                            Order thisOrder = myOrder.getValue(Order.class);
                            thisOrder.setUid(myOrder.getKey());
                            cached_orders.add(thisOrder);
                            i++;
                            if (i >= orders.getChildrenCount()) {
                                Log.d(TAG, "my order count : " + i);
                                setOrderFilter(process_spinner.getSelectedItemPosition());
                                showLoading(false);
                            }
                        }
                    } else {
                        showToast("You don't have any orders");
                        showLoading(false);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }

    //0-pending, 1-on process, 2-on delivery, 3 delivered
    public void setOrderFilter(int process_index) {
        //orderAdapter.clear();
        filtered_orders.clear();



        int i =0;
        for (Order order: cached_orders) {
            if(order.state == process_index)
            {
                //orderAdapter.add(order);
                filtered_orders.add(order);
                Log.d(TAG, "Adding " + order.orderNumber);
            }

            i++;

            if(i >= cached_orders.size())
            {

                orderAdapter.notifyDataSetChanged();
//                orders_listview.invalidateViews();
            }
        }
    }


    public void showToast(String message){
        Toast.makeText(MainActivity.context, message, Toast.LENGTH_LONG).show();
    }

    public void showLoading(boolean show)
    {
        if(show)
            loadingProgressBar.setVisibility(View.VISIBLE);
        else
            loadingProgressBar.setVisibility(View.GONE);
    }
}