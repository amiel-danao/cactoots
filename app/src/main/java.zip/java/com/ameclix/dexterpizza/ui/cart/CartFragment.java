package com.ameclix.dexterpizza.ui.cart;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.ameclix.dexterpizza.MainActivity;
import com.ameclix.dexterpizza.R;
import com.ameclix.dexterpizza.adapters.CartItemAdapter;
import com.ameclix.dexterpizza.data.model.CartItem;
import com.ameclix.dexterpizza.data.model.Food;
import com.ameclix.dexterpizza.data.model.Order;
import com.ameclix.dexterpizza.data.model.QuantityPrices;
import com.ameclix.dexterpizza.downloaded.InputFilterMinMax;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class CartFragment extends Fragment {

    public final String TAG = "myLogTag";
    private CartViewModel cartViewModel;
    public ListView cart_item_list_view;
    private CartItemAdapter cartItemAdapter;
    public ArrayList<CartItem> arrayOfCartItems = new ArrayList<>();
    public CheckBox select_all_box;
    public TextView total_cart_items;
    private TextView total_cart_price;
    private Button check_out_button;
    private ConstraintLayout loadingProgressBar;

    public AlertDialog.Builder builder;
    public View dialog_view;
    public AlertDialog alert;

    private EditText qty1_edit, qty2_edit, qty3_edit, price1, price2, price3;
    private TextView order_price_label;

    private LayoutInflater inflater;

    public ArrayList<Boolean> checks;
    public ArrayList<String> checked_items_id;

    public int checkOutPrice = 0;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        cartViewModel = ViewModelProviders.of(this).get(CartViewModel.class);

        View root = inflater.inflate(R.layout.fragment_cart, container, false);

        checks = new ArrayList<Boolean>();
        checked_items_id = new ArrayList<String>();

        if(savedInstanceState != null)
        {
            boolean[] chk = savedInstanceState.getBooleanArray("savedChecks");

            for(Boolean text:chk) {
                checks.add(text);
            }

            checked_items_id = savedInstanceState.getStringArrayList("savedIdChecks");
        }

        cart_item_list_view = root.findViewById(R.id.cart_list_view);
        cartItemAdapter = new CartItemAdapter(MainActivity.context, arrayOfCartItems, this);

        cart_item_list_view.setAdapter(cartItemAdapter);

        select_all_box = root.findViewById(R.id.select_all_box);
        total_cart_items = root.findViewById(R.id.total_cart_items);
        total_cart_price = root.findViewById(R.id.total_cart_price);
        check_out_button = root.findViewById(R.id.check_out_button);
        loadingProgressBar = root.findViewById(R.id.loading_constraint);

        getCartItemsFromDB();




        this.inflater = inflater;
        return root;
    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        Object[] array = checks.toArray();
        boolean[] booleans = new boolean[array.length];

        //Iterate and convert to desired type
        for(int i=0; i<array.length; i++) {
            boolean s = (Boolean) array[i];
            booleans[i] = s;
        }
        outState.putBooleanArray("savedChecks", booleans);



        outState.putStringArrayList("savedIdChecks", checked_items_id);
    }

    public void setTotalCartPrice(int totalCartPrice)
    {
        total_cart_price.setText("₱" + totalCartPrice);
    }

    private void setButtonListener() {


        //set check out button listener
        check_out_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                //List<String> allChecked = cartItemAdapter.getAllCheckedCartItems();
                final List<CartItem> cartChecked = new ArrayList<>();



                if(checked_items_id.size() == 0){
                    showToast("Please select at least one item to check out!");
                    return;}


                //check each item if enough stock1


                //List<String> checkedItems = new ArrayList<>();
//                for (String box_name: checked_items_id  ) {
//
//                }
                //String toCheckOutNames = "";
                for (CartItem cartItem: arrayOfCartItems) {
                    String key = cartItem.getItem_id();
                    int index = arrayOfCartItems.indexOf(cartItem);
//                    if(cartItemAdapter.cartItemCheckBoxes.get(key).isChecked()) {
                    if(checks.get(index)) {
                        //checkedItems.add(box_name);
                        cartChecked.add(cartItem);
                        //toCheckOutNames += cartItem.item_name + " ";
                    }
                }


                if(cartChecked.size() == 0){
                    showToast("Please select at least one item to check out!");
                    return;}

                //showToast(toCheckOutNames);

                //try to save all cart items to order

                //dialog_view = foodFragment.inflater.inflate(R.layout.dia, null);
                builder = new AlertDialog.Builder(MainActivity.context).setCancelable(false);

                alert = builder.setMessage("Proceed checking out " + cartChecked.size() + " items total of ₱" + checkOutPrice +"?").setTitle("Confirm checkout?").setPositiveButton("Yes", null)
                        .setNegativeButton("No", null).create();

                alert.setCanceledOnTouchOutside(false);

                //override dismiss
                alert.setOnShowListener(new DialogInterface.OnShowListener() {

                    @Override
                    public void onShow(DialogInterface dialogInterface) {
                        final Button positiveButton = alert.getButton(AlertDialog.BUTTON_POSITIVE);

                        positiveButton.setOnClickListener(new View.OnClickListener() {

                            @Override
                            public void onClick(View view) {
                                alert.hide();
                                showLoading(true);

                                final int[] i = {0};
                                final HashMap<String, Integer> food_stock1_remaining = new HashMap<>();
                                final HashMap<String, Integer> food_stock2_remaining = new HashMap<>();
                                final HashMap<String, Integer> food_stock3_remaining = new HashMap<>();

                                //check all items on checked cart it it has enough stock1
                                for (final CartItem cartItem : cartChecked) {

                                    final FirebaseDatabase database = FirebaseDatabase.getInstance();
                                    //check qty of food to order
                                    final DatabaseReference foodCheckRef = database.getReference("foods/" + cartItem.getItem_id());


                                    foodCheckRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            Food food_to_check = dataSnapshot.getValue(Food.class);

                                            if (food_to_check != null) {
                                                food_stock1_remaining.put(dataSnapshot.getKey(), food_to_check.stock1);
                                                food_stock2_remaining.put(dataSnapshot.getKey(), food_to_check.stock2);
                                                food_stock3_remaining.put(dataSnapshot.getKey(), food_to_check.stock3);

                                                String stock_lack_message = "";

                                                if (food_to_check.getStock1() < cartItem.myQtys.qty1)
                                                    stock_lack_message += food_to_check.stock1 + " Small,";

                                                Log.d(TAG,"Small stock : " + food_to_check.getStock1());

                                                if (food_to_check.getStock2() < cartItem.myQtys.qty2)
                                                    stock_lack_message += food_to_check.getStock2() + " Medium,";

                                                if (food_to_check.getStock3() < cartItem.myQtys.qty3)
                                                    stock_lack_message += food_to_check.getStock3() + " Large.";


                                                if (stock_lack_message.length() > 0) {

                                                    stock_lack_message = "Sorry, "+ food_to_check.getFood_name() + " insufficient stock, " + stock_lack_message.substring(0, stock_lack_message.length()-1) + " available.";
                                                    AlertDialog.Builder b = new AlertDialog.Builder(MainActivity.context).setCancelable(false);

                                                    AlertDialog a = b.setMessage(stock_lack_message).setTitle("Item insufficient stock").setPositiveButton("Ok", null).create();
                                                    a.show();

                                                    alert.dismiss();
                                                    showLoading(false);
                                                    check_out_button.setClickable(true);
                                                    return;
                                                }
                                            }
                                            else
                                            {
                                                AlertDialog.Builder b = new AlertDialog.Builder(MainActivity.context).setCancelable(false);

                                                AlertDialog a = b.setMessage("Item doesn't exists!").setTitle("Error").setPositiveButton("Ok", null).create();
                                                a.show();
                                            }

                                            i[0]++;

                                            if (i[0] >= cartChecked.size())
                                            {
                                                //alert.show();
                                                Log.d(TAG, "from here");

                                                //subtract stock quantities
                                                int k = 0;
                                                for (final CartItem ok_cartItem: cartChecked) {

//                                          Food food = dataSnapshot.getValue(Food.class);
                                                    int newStockQty1 = Math.max(0, food_stock1_remaining.get(ok_cartItem.getItem_id()) - ok_cartItem.myQtys.getQty1());
                                                    int newStockQty2 = Math.max(0, food_stock2_remaining.get(ok_cartItem.getItem_id()) - ok_cartItem.myQtys.getQty2());
                                                    int newStockQty3 = Math.max(0, food_stock3_remaining.get(ok_cartItem.getItem_id()) - ok_cartItem.myQtys.getQty3());

                                                    HashMap<String, Object> updateQty = new HashMap<>();
                                                    updateQty.put("stock1", newStockQty1);
                                                    updateQty.put("stock2", newStockQty2);
                                                    updateQty.put("stock3", newStockQty3);

                                                    FirebaseDatabase.getInstance().getReference("foods/" + ok_cartItem.getItem_id()).updateChildren(updateQty);

                                                    k++;

                                                    if(k >= cartChecked.size()) {
                                                        //get the next order number
                                                        FirebaseDatabase.getInstance().getReference("orderNum").addListenerForSingleValueEvent(new ValueEventListener() {
                                                            @Override
                                                            public void onDataChange(@NonNull DataSnapshot currOrderNum) {
                                                                final int orderNum = currOrderNum.getValue(Integer.class) + 1;


                                                                FirebaseDatabase.getInstance().getReference("orderNum").setValue(orderNum).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                    @Override
                                                                    public void onComplete(@NonNull Task<Void> task) {
                                                                        //String formatted = String.format("%03d", num);

                                                                        final FirebaseDatabase database = FirebaseDatabase.getInstance();
                                                                        final DatabaseReference myRef = database.getReference("orders");

                                                                        DateFormat sdf = new SimpleDateFormat("MMMM dd, YYYY hh:mm a");

                                                                        Date date = new Date();
                                                                        String date_ordered = sdf.format(date);

                                                                        Order newOrder = new Order(
                                                                                "",
                                                                                MainActivity.loggedUser.getUserId(),
                                                                                MainActivity.loggedUser.getFirst_name() + " " + MainActivity.loggedUser.getLast_name(),
                                                                                MainActivity.loggedUser.getAddress(),
                                                                                MainActivity.loggedUser.getPhone(),
                                                                                cartChecked,
                                                                                checkOutPrice,
                                                                                date_ordered,
                                                                                "",
                                                                                0,
                                                                                orderNum
                                                                        );

                                                                        //remove cart item local copies
                                                                        arrayOfCartItems.removeAll(cartChecked);

                                                                        for (String str : checked_items_id) {
                                                                            cartItemAdapter.placedCartPrices.remove(str);
                                                                        }

                                                                        final ArrayList<String> copy_of_checked = (ArrayList<String>) checked_items_id.clone();
                                                                        checked_items_id.clear();


                                                                        cartItemAdapter.notifyDataSetChanged();

                                                                        myRef.push().setValue(newOrder).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                            @Override
                                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                                //remove selected items from cart
                                                                                FirebaseDatabase.getInstance().getReference("users/" + MainActivity.loggedUser.getUserId() + "/cart").addListenerForSingleValueEvent(new ValueEventListener() {
                                                                                    @Override
                                                                                    public void onDataChange(@NonNull DataSnapshot cartItems) {
                                                                                        for (DataSnapshot cartItem : cartItems.getChildren()) {
                                                                                            if (copy_of_checked.contains(cartItem.getKey())) {
                                                                                                FirebaseDatabase.getInstance().getReference("users/" + MainActivity.loggedUser.getUserId() + "/cart/" + cartItem.getKey()).removeValue();
                                                                                                setTotalCartPrice(cartItemAdapter.getTotalCartPrices());
                                                                                                showLoading(false);
                                                                                                MainActivity.navController.navigate(R.id.nav_my_orders);
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    @Override
                                                                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                                                                    }
                                                                                });
                                                                            }
                                                                        });


                                                                    }
                                                                });

                                                                alert.dismiss();
                                                            }

                                                            @Override
                                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                                            }
                                                        });
                                                    }
                                                }
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                        }
                                    });


                                }
                            }
                        });
                    }
                });


                alert.show();

            }
        });
        //set select all listener

        select_all_box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isChecked = select_all_box.isChecked();
                int i=0;
                for (String str : cartItemAdapter.cartItemCheckBoxes.keySet()) {
                    CheckBox checkBox = cartItemAdapter.cartItemCheckBoxes.get(str);
                    checkBox.setChecked(isChecked);

                    if(checks.size() > i)
                        checks.set(i, isChecked);
                    //checkBox.invalidate();
                    cartItemAdapter.notifyDataSetChanged();


                    if(isChecked) {
                        if(!checked_items_id.contains(str))
                            checked_items_id.add(str);
                    }
                    else {
                        if(checked_items_id.contains(str))
                            checked_items_id.remove(str);
                    }

                    i++;

                    Log.d(TAG, "setting checkbox : " + checkBox);
                    if(i >= cartItemAdapter.cartItemCheckBoxes.keySet().size())
                    {
                        setTotalCartPrice(cartItemAdapter.getTotalCartPrices());
                    }
                }
            }
        });
    }


    public void showICartItemEditDialog(String title, final CartItem origCartItem, final String Yes, String No) {
        //LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        dialog_view = inflater.inflate(R.layout.cart_item_edit, null);
        builder = new AlertDialog.Builder(MainActivity.context).setCancelable(false);


        //get all fields
        final EditText food_name_edit = dialog_view.findViewById(R.id.food_name_edit);

        price1 = dialog_view.findViewById(R.id.price1_edit);
        price2 = dialog_view.findViewById(R.id.price2_edit);
        price3 = dialog_view.findViewById(R.id.price3_edit);

        final ConstraintLayout loading_dialog_constraint = dialog_view.findViewById(R.id.loading_dialog_constraint);

        final Food theFoodInfo = MainActivity.foodByName.get(origCartItem.item_id);
        // show item info
        if (origCartItem != null) {
            //fill all fields from original food
            food_name_edit.setText(origCartItem.item_name);
            price1.setText(String.valueOf(theFoodInfo.price1));
            price2.setText(String.valueOf(theFoodInfo.price2));
            price3.setText(String.valueOf(theFoodInfo.price3));
        }


        alert = builder.setView(dialog_view).setTitle(title).setPositiveButton(Yes, null)
                .setNegativeButton(No, null).create();

        alert.setCanceledOnTouchOutside(false);

        order_price_label = dialog_view.findViewById(R.id.order_price_label);

        qty1_edit = dialog_view.findViewById(R.id.qty1_edit);
        qty1_edit.setFilters(new InputFilter[]{new InputFilterMinMax("0", "999")});
        qty1_edit.setText(""+origCartItem.myQtys.qty1);

        qty2_edit = dialog_view.findViewById(R.id.qty2_edit);
        qty2_edit.setFilters(new InputFilter[]{new InputFilterMinMax("0", "999")});
        qty2_edit.setText(""+origCartItem.myQtys.qty2);

        qty3_edit = dialog_view.findViewById(R.id.qty3_edit);
        qty3_edit.setFilters(new InputFilter[]{new InputFilterMinMax("0", "999")});
        qty3_edit.setText(""+origCartItem.myQtys.qty3);

        computeOrderPrice(theFoodInfo);

        //enable qty controls for set prices only
        qty1_edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                computeOrderPrice(theFoodInfo);
            }
        });

        qty2_edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                computeOrderPrice(theFoodInfo);
            }
        });

        qty3_edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                computeOrderPrice(theFoodInfo);
            }
        });

        if(theFoodInfo.price1 == 0)
            price1.setText("-");
        else {
            price1.setText("₱" + theFoodInfo.price1);
            LinearLayout qty_controls1 = dialog_view.findViewById(R.id.qty_controls1);
            qty_controls1.setVisibility(View.VISIBLE);
            dialog_view.findViewById(R.id.up_qty1).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d(TAG, qty1_edit.getText().toString());
                    modifyQtyValue(v);

                    computeOrderPrice(theFoodInfo);
                }
            });

            dialog_view.findViewById(R.id.down_qty1).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    modifyQtyValue(v);

                    computeOrderPrice(theFoodInfo);
                }
            });
        }

        if(theFoodInfo.price2 == 0)
            price2.setText("-");
        else {
            price2.setText("₱" + theFoodInfo.price2);
            LinearLayout qty_controls2 = dialog_view.findViewById(R.id.qty_controls2);
            qty_controls2.setVisibility(View.VISIBLE);

            dialog_view.findViewById(R.id.up_qty2).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    modifyQtyValue(v);

                    computeOrderPrice(theFoodInfo);
                }
            });

            dialog_view.findViewById(R.id.down_qty2).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    modifyQtyValue(v);

                    computeOrderPrice(theFoodInfo);
                }
            });
        }

        if(theFoodInfo.price3 == 0)
            price3.setText("-");
        else {
            price3.setText("₱" + theFoodInfo.price3);
            LinearLayout qty_controls3 = dialog_view.findViewById(R.id.qty_controls3);
            qty_controls3.setVisibility(View.VISIBLE);

            dialog_view.findViewById(R.id.up_qty3).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    modifyQtyValue(v);

                    computeOrderPrice(theFoodInfo);
                }
            });

            dialog_view.findViewById(R.id.down_qty3).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    modifyQtyValue(v);

                    computeOrderPrice(theFoodInfo);
                }
            });
        }


        alert.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                final Button positiveButton = alert.getButton(AlertDialog.BUTTON_POSITIVE);
                final Button negativeButton = alert.getButton(AlertDialog.BUTTON_NEGATIVE);


                positiveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Log.d(TAG, "add to cart dialog button");
                        loading_dialog_constraint.setVisibility(View.VISIBLE);
                        positiveButton.setEnabled(false);
                        negativeButton.setEnabled(false);

                        //check if all qty have atleast a value
                        if(getEditTextIntValue(qty1_edit) == 0 && getEditTextIntValue(qty2_edit) == 0 && getEditTextIntValue(qty3_edit) == 0)
                        {
                            showToast("Please enter quantity value!");
                            loading_dialog_constraint.setVisibility(View.GONE);
                            positiveButton.setEnabled(true);
                            negativeButton.setEnabled(true);
                            return;
                        }





                        QuantityPrices quantityPrices = new QuantityPrices(
                                Integer.parseInt(qty1_edit.getText().toString()),
                                Integer.parseInt(qty2_edit.getText().toString()),
                                Integer.parseInt(qty3_edit.getText().toString()));

                        final CartItem newCartItem = new CartItem(food_name_edit.getText().toString(), quantityPrices);

                        //try to add item on cart
                        final String editedName = newCartItem.item_name.toLowerCase().trim().replaceAll(" +", " ").replaceAll(" ", "_");
                        final FirebaseDatabase database = FirebaseDatabase.getInstance();
                        final DatabaseReference myRef = database.getReference("users/" + MainActivity.loggedUser.getUserId() + "/cart/"+editedName);

                        newCartItem.setItem_id(editedName);

                        //check qty of food to order
                        final DatabaseReference foodCheckRef = FirebaseDatabase.getInstance().getReference("foods/" + editedName);

                        foodCheckRef.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                Food food_to_check = dataSnapshot.getValue(Food.class);

                                if (food_to_check != null) {
                                    String stock_lack_message = "";

                                    if (food_to_check.getStock1() < newCartItem.myQtys.qty1)
                                        stock_lack_message += food_to_check.getStock1() + " Small,";

                                    if (food_to_check.getStock2() < newCartItem.myQtys.qty2)
                                        stock_lack_message += food_to_check.getStock2() + " Medium,";

                                    if (food_to_check.getStock3() < newCartItem.myQtys.qty3)
                                        stock_lack_message += food_to_check.getStock3() + " Large.";

                                    if(stock_lack_message.length() == 0) {
                                        //get the same existing cart item
                                        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot cartItem) {
                                                //if item already exist on cart

                                                myRef.setValue(newCartItem).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        showToast("Item quantity updated successfully");
                                                        alert.dismiss();

                                                        int origCartItemIndex = arrayOfCartItems.indexOf(origCartItem);
                                                        arrayOfCartItems.set(origCartItemIndex, newCartItem);

                                                        cartItemAdapter.placedCartPrices.put(editedName, computeOrderPrice(theFoodInfo));
                                                        cartItemAdapter.notifyDataSetChanged();
                                                        //setTotalCartPrice(cartItemAdapter.getTotalCartPrices());
                                                        loading_dialog_constraint.setVisibility(View.GONE);
                                                    }
                                                });
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                            }
                                        });
                                    }
                                    else
                                    {
                                        stock_lack_message = "Sorry, "+ food_to_check.getFood_name() + " insufficient stock, " + stock_lack_message.substring(0, stock_lack_message.length()-1) + ".";
                                        AlertDialog.Builder b = new AlertDialog.Builder(MainActivity.context).setCancelable(false);

                                        AlertDialog a = b.setMessage(stock_lack_message).setTitle("Item insufficient stock").setPositiveButton("Ok", null).create();
                                        a.show();

                                        loading_dialog_constraint.setVisibility(View.GONE);
                                        positiveButton.setEnabled(true);
                                        negativeButton.setEnabled(true);
                                    }
                                }
                                else
                                {
                                    AlertDialog.Builder b = new AlertDialog.Builder(MainActivity.context).setCancelable(false);

                                    AlertDialog a = b.setMessage("Item doesn't exists!").setTitle("Item insufficient stock").setPositiveButton("Ok", null).create();
                                    a.show();
                                    loading_dialog_constraint.setVisibility(View.GONE);
                                    positiveButton.setEnabled(true);
                                    negativeButton.setEnabled(true);
                                }

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                });

                negativeButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Log.d(TAG, "cancel cart dialog button");
                        alert.dismiss();
                    }
                });
            }
        });

        alert.show();
    }


    public void modifyQtyValue(View view)
    {
        switch (view.getId())
        {
            case R.id.up_qty1 :
                int addVal1 = 0;
                if(!qty1_edit.getText().toString().isEmpty())
                    addVal1 = Math.max(0, Integer.parseInt(qty1_edit.getText().toString()) + 1);
                qty1_edit.setText(String.valueOf(addVal1));break;
            case R.id.up_qty2 :  int addVal2 = 0;
                if(!qty2_edit.getText().toString().isEmpty())
                    addVal2 = Math.max(0, Integer.parseInt(qty2_edit.getText().toString()) + 1);
                qty2_edit.setText(String.valueOf(addVal2));break;
            case R.id.up_qty3 :  int addVal3 = 0;
                if(!qty3_edit.getText().toString().isEmpty())
                    addVal3 = Math.max(0, Integer.parseInt(qty3_edit.getText().toString()) + 1);
                qty3_edit.setText(String.valueOf(addVal3));break;



            case R.id.down_qty1 :
                int subVal1 = 0;
                if(!qty1_edit.getText().toString().isEmpty())
                    subVal1 = Math.max(0, Integer.parseInt(qty1_edit.getText().toString()) - 1);
                qty1_edit.setText(String.valueOf(subVal1));break;
            case R.id.down_qty2 :
                int subVal2 = 0;
                if(!qty2_edit.getText().toString().isEmpty())
                    subVal2 = Math.max(0, Integer.parseInt(qty2_edit.getText().toString()) - 1);
                qty2_edit.setText(String.valueOf(subVal2));break;

            case R.id.down_qty3 :
                int subVal3 = 0;
                if(!qty3_edit.getText().toString().isEmpty())
                    subVal3 = Math.max(0, Integer.parseInt(qty3_edit.getText().toString()) - 1);
                qty3_edit.setText(String.valueOf(subVal3));break;
        }
    }

    private int computeOrderPrice(Food food)
    {
        int orderPrice = 0;
        if(food != null) {
            orderPrice = (food.price1 * getEditTextIntValue(qty1_edit)) + (food.price2 * getEditTextIntValue(qty2_edit)) + (food.price3 * getEditTextIntValue(qty3_edit));
            order_price_label.setText("Order Price : ₱" + orderPrice);
        }
        return orderPrice;
    }

    private int getEditTextIntValue(EditText edit)
    {
        int retVal = 0;

        if(!edit.getText().toString().isEmpty())
            retVal = Integer.parseInt(edit.getText().toString());

        return retVal;
    }

    private void getCartItemsFromDB()
    {
        showLoading(true);
        arrayOfCartItems.clear();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("users/" + MainActivity.loggedUser.getUserId() + "/cart");

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot cart) {
                if(cart.exists())
                {
                    int i =0;

                    total_cart_items.setText(""+cart.getChildrenCount());
                    for (DataSnapshot cart_item: cart.getChildren()) {

                        CartItem newCartItem = cart_item.getValue(CartItem.class);
                        newCartItem.setItem_id(cart_item.getKey());
                        arrayOfCartItems.add(newCartItem);
                        checks.add(false);


                        Log.d(TAG, "i : "+i);
                        i++;

                        //done reading cart
                        if(i >= cart.getChildrenCount())
                        {
                            cartItemAdapter.notifyDataSetChanged();
                            cart_item_list_view.invalidateViews();
                            setButtonListener();


                            showLoading(false);
                        }
                    }
                }
                else
                {
                    showLoading(false);
                    MainActivity.showToast("Your cart is empty");
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void showLoading(boolean show)
    {
        if(show) {
            loadingProgressBar.setVisibility(View.VISIBLE);
            check_out_button.setClickable(false);
        }
        else {
            loadingProgressBar.setVisibility(View.GONE);

        }
    }

    private void showToast(String message){
        Toast.makeText(MainActivity.context, message, Toast.LENGTH_LONG).show();
    }

}