package com.ameclix.dexterpizza.ui.profile;

import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.ameclix.dexterpizza.MainActivity;
import com.ameclix.dexterpizza.R;
import com.ameclix.dexterpizza.data.model.LoggedInUser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.SignInMethodQueryResult;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ProfileFragment extends Fragment {

    public final String TAG = "myLogTag";
    private ProfileViewModel profileViewModel;
    private List<EditText> requiredFields;
    private EditText password_field, confirm_password_field, email_field;
    private ConstraintLayout loadingProgressBar;
    private EditText first_name;
    private EditText last_name;
    private EditText phone;
    private EditText address;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        profileViewModel =
                ViewModelProviders.of(this).get(ProfileViewModel.class);
        View root = inflater.inflate(R.layout.fragment_profile, container, false);

        first_name = root.findViewById(R.id.first_name);
        last_name = root.findViewById(R.id.last_name);
        phone = root.findViewById(R.id.phone_field);
        address = root.findViewById(R.id.address_field);

        email_field = root.findViewById(R.id.email_field);
        password_field = root.findViewById(R.id.password_field);
        confirm_password_field = root.findViewById(R.id.password_confirm_field);
        Button save_profile = root.findViewById(R.id.save_profile_button);

        loadingProgressBar = root.findViewById(R.id.loading_constraint);
        
        //required register fields
        requiredFields = new ArrayList<>();
        requiredFields.add(first_name);
        requiredFields.add(last_name);
        requiredFields.add(phone);
        requiredFields.add(address);

        ImageView show_pass_btn = root.findViewById(R.id.show_pass_btn);
        ImageView show_pass_confirm_btn = root.findViewById(R.id.show_pass_confirm_btn);

        show_pass_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowHidePass(v);
            }
        });

        show_pass_confirm_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowHidePass(v);
            }
        });

        save_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //check all required fields first
                EditText invalidRequiredField = isValidInputFieldsRequired(requiredFields);
                if(invalidRequiredField == null) {
                    //then validate email and password
                    if (profileDataChanged(email_field.getText().toString(), password_field.getText().toString(), confirm_password_field.getText().toString())) {
                        tryUpdateProfile(email_field.getText().toString(), password_field.getText().toString());
                    }
                    else
                    {
                        loadingProgressBar.setVisibility(View.GONE);
                    }
                }
                else
                {
                    invalidRequiredField.setError("This field is required!");
                    loadingProgressBar.setVisibility(View.GONE);
                }
            }
        });


        fillProfileFields();

        return root;
    }

    private void fillProfileFields() {
        LoggedInUser user = MainActivity.loggedUser;
        first_name.setText(user.getFirst_name());
        last_name.setText(user.getLast_name());
        phone.setText(user.getPhone());
        address.setText(user.getAddress());
        email_field.setText(user.getEmail());
        password_field.setText(user.getPassword());
        confirm_password_field.setText(user.getPassword());
    }

    private void tryUpdateProfile(final String newEmail, final String newPassword) {
        loadingProgressBar.setVisibility(View.VISIBLE);
        if(MainActivity.isAdmin)
        {
            //check if this admin email is already registered
            FirebaseAuth.getInstance().fetchSignInMethodsForEmail(newEmail)
                    .addOnCompleteListener(new OnCompleteListener<SignInMethodQueryResult>() {
                        @Override
                        public void onComplete(@NonNull Task<SignInMethodQueryResult> task) {

                            boolean isNewUser = task.getResult().getSignInMethods().isEmpty();

                            if (isNewUser) {
                                MainActivity.loggedUser = new LoggedInUser();
                                MainActivity.loggedUser.setFirst_name(first_name.getText().toString());
                                MainActivity.loggedUser.setLast_name(last_name.getText().toString());
                                MainActivity.loggedUser.setAddress(address.getText().toString());
                                MainActivity.loggedUser.setPhone(phone.getText().toString());

                                MainActivity.loggedUser.setEmail(newEmail);
                                MainActivity.loggedUser.setEmail(newPassword);

                                FirebaseDatabase database = FirebaseDatabase.getInstance();
                                DatabaseReference myRef = database.getReference("admin");

                                myRef.setValue(MainActivity.loggedUser).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if(task.isSuccessful())
                                            showToast("User profile updated successfully.");
                                        else
                                            showToast(task.getException().getMessage());

                                        loadingProgressBar.setVisibility(View.GONE);
                                    }
                                });

                            } else {
                                showToast("Email already taken!");
                            }

                        }
                    });
        }
        else {
            final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

            user.updateEmail(newEmail)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                //Log.d(TAG, "User email address updated.");
                                user.updatePassword(newPassword)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    //Log.d(TAG, "User password updated.");
                                                    updateNewUserToDB(user);
                                                }
                                            }
                                        });
                            } else {
                                showToast(task.getException().getMessage());
                                loadingProgressBar.setVisibility(View.GONE);
                            }
                        }
                    });

        }

    }

    private void updateNewUserToDB(FirebaseUser user)
    {
        LoggedInUser updatedUser = new LoggedInUser();

        updatedUser.setEmail(user.getEmail());
        updatedUser.setPassword(password_field.getText().toString());
        updatedUser.setFirst_name(first_name.getText().toString());
        updatedUser.setLast_name(last_name.getText().toString());
        updatedUser.setPhone(phone.getText().toString());
        updatedUser.setAddress(address.getText().toString());


        DatabaseReference mRef = FirebaseDatabase.getInstance().getReference("users");
        mRef.child(user.getUid()).setValue(updatedUser).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()) {
                    showToast("User profile updated successfully.");
                }
                else
                {
                    showToast(task.getException().getMessage());
                }
                loadingProgressBar.setVisibility(View.GONE);
            }
        });

        MainActivity.loggedUser = updatedUser;
        //updateUI(user);
        //gotoMain(false);
    }


    public boolean profileDataChanged(String username, String password, String otherPassword) {
        if (!isUserNameValid(username)) {
            email_field.setError("Invalid email");//showToast("Invalid email!");
            return false;
            //loginFormState.setValue(new LoginFormState(R.string.invalid_username, null));
        } else if (!isPasswordValid(password)) {
            //showToast("Invalid password must be 5> characters!");
            password_field.setError("Invalid password must be 5> characters!");
            return false;
            //loginFormState.setValue(new LoginFormState(null, R.string.invalid_password));
        }
        else if(!password.equals(otherPassword)){
            //showToast("Password doesn't match!");
            confirm_password_field.setError("Password doesn't match!");
            return false;
        }
        else {
            //loginFormState.setValue(new LoginFormState(true));
            return true;
        }
    }

    private void showToast(String message){
        Toast.makeText(MainActivity.context, message, Toast.LENGTH_LONG).show();
    }

    // A placeholder username validation check
    private boolean isUserNameValid(String username) {
        if (username == null) {
            return false;
        }
        if (username.contains("@")) {
            return Patterns.EMAIL_ADDRESS.matcher(username).matches();
        } else {
            return !username.trim().isEmpty();
        }
    }

    // A placeholder password validation check
    private boolean isPasswordValid(String password) {
        return password != null && password.trim().length() > 5;
    }

    public EditText isValidInputFieldsRequired(List<EditText> fields){
        EditText result = null;
        for (EditText field: fields) {
            if(field.getText().toString().trim().isEmpty()) {
                //showToast("Please fill all required fields!");
                return field;
            }
        }
        return result;
    }

    public void ShowHidePass(View view){

        if(view.getId()==R.id.show_pass_btn){

            if(password_field.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                ((ImageView)(view)).setImageResource(R.drawable.ic_remove_red_eye_black_24dp);

                //Show Password
                password_field.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            }
            else{
                ((ImageView)(view)).setImageResource(R.drawable.ic_visibility_off_black_24dp);

                //Hide Password
                password_field.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
        }

        if(view.getId()==R.id.show_pass_confirm_btn){

            if(confirm_password_field.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                ((ImageView)(view)).setImageResource(R.drawable.ic_remove_red_eye_black_24dp);

                //Show Password
                confirm_password_field.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            }
            else{
                ((ImageView)(view)).setImageResource(R.drawable.ic_visibility_off_black_24dp);

                //Hide Password
                confirm_password_field.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
        }
    }
}