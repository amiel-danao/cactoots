package com.ameclix.dexterpizza.data.model;

import java.io.Serializable;

public class CartItem implements Serializable {
    public String item_id;
    public String item_name;
    public QuantityPrices myQtys;

    public CartItem()
    {

    }

    public CartItem(String item_name, QuantityPrices myQtys) {
        this.item_name = item_name;
        this.myQtys = myQtys;
    }

    public int getTotalPrice()
    {
        int toReturn = 0;

        toReturn = myQtys.qty1 + myQtys.qty2 + myQtys.qty3;
        return  toReturn;
    }

    public String getItem_id() {
        return item_id;
    }

    public void setItem_id(String item_id) {
        this.item_id = item_id;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public QuantityPrices getMyQtys() {
        return myQtys;
    }

    public void setMyQtys(QuantityPrices myQtys) {
        this.myQtys = myQtys;
    }
}
