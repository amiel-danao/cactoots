package com.ameclix.dexterpizza.data;

import android.util.Log;

import androidx.annotation.NonNull;

import com.ameclix.dexterpizza.data.model.LoggedInUser;
import com.ameclix.dexterpizza.ui.login.LoginActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;

import java.io.IOException;

import static com.ameclix.dexterpizza.ui.login.LoginActivity.mAuth;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
public class LoginDataSource {

    public Result<LoggedInUser> login(String username, String password) {

        try {
            // TODO: handle loggedInUser authentication
            LoggedInUser fakeUser =
                    new LoggedInUser();
            return new Result.Success<>(fakeUser);
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", null));
        }

        //FirebaseUser result = LoginActivity.instance.signInWithFirebase(username, password);

//        if(result != null){

//            LoggedInUser fakeUser =
//                    new LoggedInUser(
//                            result.getUid(),
//                            result.getDisplayName());
//            return new Result.Success<>(fakeUser);
//        }
//        else{
//            return new Result.Error(new IOException("Error logging in", null));
//        }

    }

    public void logout() {

    }
}
