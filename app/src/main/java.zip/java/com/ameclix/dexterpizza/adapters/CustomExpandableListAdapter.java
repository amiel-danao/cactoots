package com.ameclix.dexterpizza.adapters;

import java.util.HashMap;
import java.util.List;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.ameclix.dexterpizza.MainActivity;
import com.ameclix.dexterpizza.R;
import com.ameclix.dexterpizza.data.model.CartItem;
import com.ameclix.dexterpizza.data.model.Food;
import com.ameclix.dexterpizza.data.model.QuantityPrices;
import com.ameclix.dexterpizza.ui.food_menu_admin.FoodMenuAdminFragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CustomExpandableListAdapter extends BaseExpandableListAdapter{

    private Context context;
    private List<String> expandableListTitle;
    private HashMap<String, List<Food>> expandableListDetail;
    private AlertDialog alert;
    private AlertDialog.Builder builder;
    private View dialog_view;
    private FoodMenuAdminFragment foodFragment;

    public CustomExpandableListAdapter(Context context, List<String> expandableListTitle,
                                       HashMap<String, List<Food>> expandableListDetail, Fragment fragment) {
        this.context = context;
        this.expandableListTitle = expandableListTitle;
        this.expandableListDetail = expandableListDetail;

        foodFragment = ((FoodMenuAdminFragment)fragment);
        foodFragment.theCustomAdapter = this;

    }

    @Override
    public Object getChild(int listPosition, int expandedListPosition) {
        return this.expandableListDetail.get(this.expandableListTitle.get(listPosition)).get(expandedListPosition);
    }

    @Override
    public long getChildId(int listPosition, int expandedListPosition) {
        return expandedListPosition;
    }

    @Override
    public View getChildView(int listPosition, final int expandedListPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {
        final Food expandedListFood = (Food) getChild(listPosition, expandedListPosition);
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.food_menu_entry, null);
        }

        TextView expandedListTextView = (TextView) convertView
                .findViewById(R.id.cart_item_name);
        expandedListTextView.setText(Html.fromHtml("<b><big><u><font color='yellow'>" + expandedListFood.food_name + "</color></u></big></b><br>" + "<i>" + expandedListFood.description + "</i>"));

        TextView expandedFoodPrice = (TextView) convertView
                .findViewById(R.id.cart_item_price);
        expandedFoodPrice.setText("₱" + expandedListFood.price1);

        //attach click listeners
        expandedListTextView.setTag(expandedListFood);

        ImageView foodImageButton = convertView.findViewById(R.id.cart_item_image);
        foodImageButton.setTag(expandedListFood);

        if(expandedListFood.image != null) {
            if (expandedListFood.image.length() > 0) {
                //String cleanImage = expandedListFood.image.replace("data:image/png;base64,", "").replace("data:image/jpeg;base64,", "");

                byte[] decodedString = Base64.decode(expandedListFood.image, Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                foodImageButton.setImageBitmap(decodedByte);
            }
            else
            {
                Drawable d = MainActivity.context.getResources().getDrawable(R.drawable.dexter_pizza_logo);
                foodImageButton.setImageDrawable(d);
            }
        }

        if(MainActivity.isAdmin) {
            ImageView itemDeleteButton = convertView.findViewById(R.id.delete_cart_item_button);
            itemDeleteButton.setTag(expandedListFood);

            itemDeleteButton.setOnClickListener(deleteItemListener);
            itemDeleteButton.setVisibility(View.VISIBLE);

            expandedListTextView.setOnClickListener(editItemListener);
            foodImageButton.setOnClickListener(editItemListener);



            TextView stock_qty = convertView.findViewById(R.id.item_qty_stock);
            stock_qty.setVisibility(View.VISIBLE);
            String allStocksString = "stock : ";

//            if(expandedListFood.getPrice1() > 0)
                allStocksString += expandedListFood.getStock1() + "S, ";

//            if(expandedListFood.getPrice2() > 0)
                allStocksString += expandedListFood.getStock2() + "M, ";

//            if(expandedListFood.getPrice3() > 0)
                allStocksString += expandedListFood.getStock3() + "L";


            stock_qty.setText(allStocksString);
        }
        else{
            ImageView itemAddCartButton = convertView.findViewById(R.id.cart_food_button);
            itemAddCartButton.setTag(expandedListFood);

            itemAddCartButton.setOnClickListener(addCartItemListener);
            itemAddCartButton.setVisibility(View.VISIBLE);

            expandedListTextView.setOnClickListener(viewItemListener);
            foodImageButton.setOnClickListener(viewItemListener);
        }

        return convertView;
    }

    //quick add to cart
    final View.OnClickListener addCartItemListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            final Food selectedFood = (Food) view.getTag();
            // Access the row position here to get the correct data item
//            Toast.makeText(
//                    MainActivity.context, "trying to add to cart : " + selected_uid, Toast.LENGTH_LONG).show();

            final FirebaseDatabase database = FirebaseDatabase.getInstance();
            //check qty of food to order
            final DatabaseReference foodCheckRef = database.getReference("foods/" + selectedFood.uid);

            foodCheckRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Food food_to_check = dataSnapshot.getValue(Food.class);

                    if (food_to_check != null)
                    {
                        if(food_to_check.getStock1() > 0)
                        {
                            QuantityPrices quantityPrices = new QuantityPrices(1, 0, 0);

                            final CartItem newCartItem = new CartItem(selectedFood.food_name, quantityPrices);

                            //try to add item on cart
                            final String editedName = newCartItem.item_name.toLowerCase().trim().replaceAll(" +", " ").replaceAll(" ", "_");

                            final DatabaseReference myRef = database.getReference("users/" + MainActivity.loggedUser.getUserId()+"/cart/"+editedName);

                            //get the same existing cart item
                            myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot cartItem) {
                                    //if item already exist on cart
                                    if(cartItem.exists())
                                    {
                                        //then add new selected qty
                                        CartItem existingCartItem = cartItem.getValue(CartItem.class);

                                        newCartItem.myQtys.qty1 += existingCartItem.myQtys.qty1;
                                        newCartItem.myQtys.qty2 += existingCartItem.myQtys.qty2;
                                        newCartItem.myQtys.qty3 += existingCartItem.myQtys.qty3;
                                    }

                                    myRef.setValue(newCartItem).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            showToast("Item successfully added to your cart");
                                            //alert.dismiss();
                                        }
                                    });
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }
                        else
                        {
                            AlertDialog.Builder b = new AlertDialog.Builder(MainActivity.context).setCancelable(false);

                            AlertDialog a = b.setMessage("Sorry, " + selectedFood.getFood_name() + " is out of stock1").setTitle("Item out of stock1").setPositiveButton("Ok", null).create();
                            a.show();
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });


        }
    };

    private void showToast(String message){
        Toast.makeText(MainActivity.context, message, Toast.LENGTH_LONG).show();
    }

    final View.OnClickListener viewItemListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Food selectedFood = (Food) view.getTag();
            foodFragment.showItemPreviewDialog("Item details", selectedFood, "Add to cart", "Cancel");
        }
    };


    final View.OnClickListener editItemListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Food selectedFood = (Food) view.getTag();

            foodFragment.showItemPreviewDialog("Update Item", selectedFood, "Update", "Cancel");
        }
    };


    final View.OnClickListener deleteItemListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            final Food selectedFood = (Food) view.getTag();
            // Access the row position here to get the correct data item
            final String selected_uid = selectedFood.uid;
            final String selected_food_name = selectedFood.food_name;
            final String selected_category = selectedFood.category;
//            Toast.makeText(
//                        MainActivity.context, "trying to delete : " + selected_uid, Toast.LENGTH_LONG).show();

            //dialog_view = foodFragment.inflater.inflate(R.layout.dia, null);
            builder = new AlertDialog.Builder(MainActivity.context).setCancelable(false);

            alert = builder.setMessage("Are you sure you want to delete " + selected_food_name + "?").setTitle("Confirm delete item").setPositiveButton("Yes", null)
                    .setNegativeButton("No", null).create();

            alert.setCanceledOnTouchOutside(false);

            //override dismiss
            alert.setOnShowListener(new DialogInterface.OnShowListener() {

                @Override
                public void onShow(DialogInterface dialogInterface) {

                    final Button positiveButton = ((AlertDialog) alert).getButton(AlertDialog.BUTTON_POSITIVE);
//                    final Button negativeButton = ((AlertDialog) alert).getButton(AlertDialog.BUTTON_NEGATIVE);

                    positiveButton.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            final FirebaseDatabase database = FirebaseDatabase.getInstance();
                            final DatabaseReference myRef = database.getReference("foods/"+selected_uid);

                            myRef.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    Toast.makeText(
                                            MainActivity.context, selected_food_name + " successfully deleted", Toast.LENGTH_LONG).show();
                                    expandableListDetail.get(selected_category).remove(selectedFood);
                                    notifyDataSetChanged();
                                    alert.dismiss();
                                }
                            });
                        }
                    });
                }
            });

            alert.show();
        }
    };


    @Override
    public int getChildrenCount(int listPosition) {
        return this.expandableListDetail.get(this.expandableListTitle.get(listPosition))
                .size();
    }

    @Override
    public Object getGroup(int listPosition) {
        return this.expandableListTitle.get(listPosition);
    }

    @Override
    public int getGroupCount() {
        return this.expandableListTitle.size();
    }

    @Override
    public long getGroupId(int listPosition) {
        return listPosition;
    }

    @Override
    public View getGroupView(int listPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {

        String listTitle = (String) getGroup(listPosition);
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.food_list_group, null);
        }
        TextView listTitleTextView = (TextView) convertView
                .findViewById(R.id.listTitle);
        listTitleTextView.setTypeface(null, Typeface.BOLD);
        listTitleTextView.setText(listTitle);

        ImageView expandIcon = convertView.findViewById(R.id.expand_icon);
        if (isExpanded) {
            expandIcon.setImageResource(R.drawable.ic_expand_more_black_24dp);
        } else {
            expandIcon.setImageResource(R.drawable.ic_expand_less_black_24dp);
        }

        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int listPosition, int expandedListPosition) {
        return true;
    }

}