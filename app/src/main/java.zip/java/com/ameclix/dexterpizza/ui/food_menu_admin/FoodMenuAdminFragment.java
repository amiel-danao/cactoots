package com.ameclix.dexterpizza.ui.food_menu_admin;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.ameclix.dexterpizza.MainActivity;
import com.ameclix.dexterpizza.R;
import com.ameclix.dexterpizza.adapters.CustomExpandableListAdapter;
import com.ameclix.dexterpizza.data.model.CartItem;
import com.ameclix.dexterpizza.data.model.Food;
import com.ameclix.dexterpizza.data.model.QuantityPrices;
import com.ameclix.dexterpizza.downloaded.ImageFilePath;
import com.ameclix.dexterpizza.downloaded.InputFilterMinMax;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;

public class FoodMenuAdminFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 69;
    public final String TAG = "myLogTag";
    private FoodMenuAdminViewModel foodMenuAdminViewModel;

    public CustomExpandableListAdapter theCustomAdapter;
    ExpandableListView expandableListView;
    ExpandableListAdapter expandableListAdapter;
    List<String> expandableListTitle;

    private ConstraintLayout loadingProgressBar;

    private FloatingActionButton addNewItemFab;

    public LayoutInflater inflater;
    private List<String> allCategories = new ArrayList<>();
    public String selectedImageString = "";
    private Food foodProcessing;

    private AlertDialog.Builder builder;
    private View dialog_view;
    private AlertDialog alert;

    private EditText qty1_edit, qty2_edit, qty3_edit, price1, price2, price3;
    private TextView order_price_label;




    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        foodMenuAdminViewModel =
                ViewModelProviders.of(this).get(FoodMenuAdminViewModel.class);
        View root = inflater.inflate(R.layout.fragment_food_menu_admin, container, false);
        final TextView textView = root.findViewById(R.id.text_slideshow);
        foodMenuAdminViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });

        this.inflater = inflater;

        expandableListView = root.findViewById(R.id.menuExpandableListView);


        loadingProgressBar = root.findViewById(R.id.loading_constraint);
        addNewItemFab = root.findViewById(R.id.addNewItemFab);

        if(MainActivity.isAdmin)
            addNewItemFab.setVisibility(View.VISIBLE);

        getTodaysMenu();



        return root;
    }


    //get all available categories first
    private void getTodaysMenu() {
        Log.d(TAG, "Getting todays menu");

        final HashMap<String, List<Food>> currentCategories = new HashMap<String, List<Food>>();

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference myRef = database.getReference("categories");

        showLoading(true);
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot categories) {

                if(categories.exists())
                {
                    int i = 0;
                    for (DataSnapshot category: categories.getChildren()) {
                        currentCategories.put(category.getKey(), new ArrayList<Food>());
                        i ++;
                        if(i >= categories.getChildrenCount())
                        {
                            currentCategories.put("Uncategorized", new ArrayList<Food>());
                            MainActivity.food_catalog = currentCategories;
                            getFoodListFromDB();

                            //create and save category for spinner
                            allCategories = new ArrayList<>(currentCategories.keySet());
                        }
                    }
                }
                else
                {
                    showLoading(false);
                    showToast("Menu is empty");
                    generateFoodViews();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void showLoading(boolean show)
    {
        if(show)
            loadingProgressBar.setVisibility(View.VISIBLE);
        else
            loadingProgressBar.setVisibility(View.GONE);
    }

    private void attachNewItemFabListener()
    {
        addNewItemFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showItemPreviewDialog("Create New Item", null, "Save", "Cancel");
            }
        });
    }

    //add new item
    final DialogInterface.OnClickListener newItemDialogListener = new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            switch (which){
                case DialogInterface.BUTTON_POSITIVE:
                    //Yes button clicked


                    break;

                case DialogInterface.BUTTON_NEGATIVE:
                    //No button clicked
                    Log.d(TAG,"You clicked cancel!");
                    break;
            }
        }
    };

    private void showToast(String message){
        Toast.makeText(MainActivity.context, message, Toast.LENGTH_LONG).show();
    }

    private void toggleDialogButtons(View btn1, View btn2, boolean on)
    {
        if(on)
        {
            btn1.setVisibility(View.VISIBLE);
            btn2.setVisibility(View.VISIBLE);
        }
        else
        {
            btn1.setVisibility(View.GONE);
            btn2.setVisibility(View.GONE);
        }
    }

    private void setUpDownListener(int view, final EditText view2, final int increment)
    {
        dialog_view.findViewById(view).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int addVal1 = 0;
                if(!view2.getText().toString().isEmpty())
                    addVal1 = Math.max(0, Integer.parseInt(view2.getText().toString()) + increment);
                view2.setText(String.valueOf(addVal1));
            }
        });
    }

    public void showItemPreviewDialog(String title, final Food origFood, final String Yes, String No)
    {
        //LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        dialog_view = inflater.inflate(R.layout.item_preview, null);
        builder = new AlertDialog.Builder(MainActivity.context).setCancelable(false);

        //get all fields
        final EditText food_name_edit = dialog_view.findViewById(R.id.food_name_edit);
        final Spinner food_spinner = dialog_view.findViewById(R.id.category_spinner);
        TextView category_label = dialog_view.findViewById(R.id.category_label);

        final EditText food_description_edit = dialog_view.findViewById(R.id.food_description_edit);

        price1 = dialog_view.findViewById(R.id.price1_edit);
        price2 = dialog_view.findViewById(R.id.price2_edit);
        price3 = dialog_view.findViewById(R.id.price3_edit);
        final ImageView food_image = dialog_view.findViewById(R.id.food_image_edit);

        final ConstraintLayout loading_dialog_constraint = dialog_view.findViewById(R.id.loading_dialog_constraint);

        //configure fields
        food_description_edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);


        //populate category spinner
        ArrayAdapter<String> categoriesAdapterArray = new ArrayAdapter<>(MainActivity.context, android.R.layout.simple_spinner_item, allCategories);
        categoriesAdapterArray.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        food_spinner.setAdapter(categoriesAdapterArray);

        // show item info
        if(origFood != null)
        {
            //fill all fields from original food
            food_name_edit.setText(origFood.food_name);
            food_description_edit.setText(origFood.description);
            food_spinner.setSelection(allCategories.indexOf(origFood.category));
            price1.setText(String.valueOf(origFood.price1));
            price2.setText(String.valueOf(origFood.price2));
            price3.setText(String.valueOf(origFood.price3));

            if(origFood.image != null) {
                if (origFood.image.length() > 0) {
                    //String cleanImage = origFood.image.replace("data:image/png;base64,", "").replace("data:image/jpeg;base64,", "");

                    byte[] decodedString = Base64.decode(origFood.image, Base64.DEFAULT);
                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    food_image.setImageBitmap(decodedByte);

                    selectedImageString = origFood.image;
                }
            }
        }

        alert = builder.setView(dialog_view).setTitle(title).setPositiveButton(Yes, null)
                .setNegativeButton(No, null).create();

        alert.setCanceledOnTouchOutside(false);

        //enable editing text for admin
        if(MainActivity.isAdmin)
        {
            ImageView image_remove_edit = dialog_view.findViewById(R.id.image_remove_edit);
            image_remove_edit.setVisibility(View.VISIBLE);
            image_remove_edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //set default image
                    Drawable d = MainActivity.context.getResources().getDrawable(R.drawable.dexter_pizza_logo);
                    food_image.setImageDrawable(d);
                    selectedImageString = "";
                }
            });


            LinearLayout item_qty_group = dialog_view.findViewById(R.id.item_qty_group);
            item_qty_group.setVisibility(View.VISIBLE);

            final EditText food_qty_edit1 = dialog_view.findViewById(R.id.item_qty_edit1);
            if(origFood != null)
                food_qty_edit1.setText(String.valueOf(origFood.getStock1()));
            else
                food_qty_edit1.setText("0");

            //add change quantity listener
            setUpDownListener(R.id.up_item_qty1, food_qty_edit1, 1);
            setUpDownListener(R.id.down_item_qty1, food_qty_edit1, -1);

            final EditText food_qty_edit2 = dialog_view.findViewById(R.id.item_qty_edit2);

            if(origFood != null)
                food_qty_edit2.setText(String.valueOf(origFood.getStock2()));
            else
                food_qty_edit2.setText("0");

            setUpDownListener(R.id.up_item_qty2, food_qty_edit2, 1);
            setUpDownListener(R.id.down_item_qty2, food_qty_edit2, -1);

            final EditText food_qty_edit3 = dialog_view.findViewById(R.id.item_qty_edit3);

            if(origFood != null)
                food_qty_edit3.setText(String.valueOf(origFood.getStock3()));
            else
                food_qty_edit3.setText("0");

            setUpDownListener(R.id.up_item_qty3, food_qty_edit3, 1);
            setUpDownListener(R.id.down_item_qty3, food_qty_edit3, -1);


            food_name_edit.setEnabled(true);
            food_spinner.setVisibility(View.VISIBLE);
            category_label.setVisibility(View.VISIBLE);
            food_description_edit.setEnabled(true);
            price1.setEnabled(true);
            price1.setTextIsSelectable(true);
            price2.setEnabled(true);
            price2.setTextIsSelectable(true);
            price3.setEnabled(true);
            price3.setTextIsSelectable(true);

            food_qty_edit1.setEnabled(true);
            food_qty_edit1.setTextIsSelectable(true);

            //attach food image browser
            food_image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
                }
            });

            alert.setOnShowListener(new DialogInterface.OnShowListener() {

                @Override
                public void onShow(DialogInterface dialogInterface) {

                    final Button positiveButton = alert.getButton(AlertDialog.BUTTON_POSITIVE);
                    final Button negativeButton = alert.getButton(AlertDialog.BUTTON_NEGATIVE);

                    positiveButton.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            Log.d(TAG,"You clicked ok on new item save!");
                            loading_dialog_constraint.setVisibility(View.VISIBLE);
                            toggleDialogButtons(positiveButton, negativeButton, false);

                            int p1 = 0, p2 = 0, p3 = 0, qty1 = 0, qty2 = 0, qty3 = 0;
                            if(price1.getText().toString().length() > 0)
                                p1 = Math.min(999999, Math.abs(Integer.parseInt(price1.getText().toString())));
                            if(price2.getText().toString().length() > 0)
                                p2 = Math.min(999999, Math.abs(Integer.parseInt(price2.getText().toString())));
                            if(price3.getText().toString().length() > 0)
                                p3 = Math.min(999999, Math.abs(Integer.parseInt(price3.getText().toString())));

                            //Integer.parseInt(String.valueOf(food_qty_edit1.getText()))
                            if(food_qty_edit1.getText().length() > 0)
                                qty1 = Math.min(999999, Math.abs(Integer.parseInt(food_qty_edit1.getText().toString())));

                            if(food_qty_edit2.getText().length() > 0)
                                qty2 = Math.min(999999, Math.abs(Integer.parseInt(food_qty_edit2.getText().toString())));

                            if(food_qty_edit3.getText().length() > 0)
                                qty3 = Math.min(999999, Math.abs(Integer.parseInt(food_qty_edit3.getText().toString())));

                            //validate blank fields
                            if(food_name_edit.getText().toString().length() == 0)
                            {
                                showToast("Please enter food name");
                                loading_dialog_constraint.setVisibility(View.GONE);
                                toggleDialogButtons(positiveButton, negativeButton, true);
                                return;
                            }

                            //edit mode
                            foodProcessing = new Food(
                                    food_name_edit.getText().toString(),
                                    food_spinner.getSelectedItem().toString(),
                                    food_description_edit.getText().toString(),
                                    "",
                                    p1,
                                    p2,
                                    p3,
                                    qty1,
                                    qty2,
                                    qty3);

                            if(selectedImageString != null) {
                                if (selectedImageString.length() > 0)
                                    foodProcessing.setImage(selectedImageString);
                            }
                            //Log.d(TAG, foodProcessing.image);

                            //check if item name already exist
                            final String editedName = foodProcessing.food_name.toLowerCase().trim().replaceAll(" +", " ").replaceAll(" ", "_");
                            final FirebaseDatabase database = FirebaseDatabase.getInstance();
                            final DatabaseReference myRef = database.getReference("foods/" + editedName);

                            myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot food) {

                                    //its ok that record already exist if that record is from original record
                                    if((food.exists() && origFood != null && !origFood.uid.equals(editedName)) || (food.exists() && origFood == null))
                                    {
                                        //Log.d(TAG, "orig : " + origFood.uid + ", edited : " + editedName);
                                        ///showLoading(false);
                                        showToast("Food item already exists!");
                                        loading_dialog_constraint.setVisibility(View.GONE);
                                        toggleDialogButtons(positiveButton, negativeButton, true);
                                    }
                                    else
                                    {
                                        Log.d(TAG, "edited image : " + foodProcessing.image);
                                        //push new food
                                        database.getReference("foods/" + editedName).setValue(foodProcessing).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                //add local menu entry with reloading database
                                                loading_dialog_constraint.setVisibility(View.GONE);
                                                //toggleDialogButtons(positiveButton, negativeButton, true);



                                                if(origFood != null){
                                                    //delete old item record if new id has changed
                                                    if(!editedName.equals(origFood.uid)) {
                                                        database.getReference("foods/" + origFood.uid).removeValue();
                                                    }
                                                    MainActivity.food_catalog.get(origFood.category).remove(origFood);
                                                    MainActivity.food_catalog.get(foodProcessing.category).add(foodProcessing);

                                                    showToast("Item updated successfully!");
                                                }
                                                else
                                                {
                                                    MainActivity.food_catalog.get(foodProcessing.category).add(foodProcessing);
                                                    showToast("New item added successfully!");
                                                }


                                                alert.dismiss();
                                                //selectedImageString = "";
                                                //theCustomAdapter.notifyDataSetChanged();
                                                foodProcessing = null;
                                            }
                                        });
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }
                    });

                    negativeButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alert.dismiss();
                            selectedImageString = "";
                            foodProcessing = null;
                        }
                    });
                }
            });
        }
        else
        {
            //client view mode

            LinearLayout client_qty_group = dialog_view.findViewById(R.id.client_qty_group);
            client_qty_group.setVisibility(View.VISIBLE);

            order_price_label = dialog_view.findViewById(R.id.order_price_label);

            qty1_edit = dialog_view.findViewById(R.id.qty1_edit);
            qty1_edit.setFilters(new InputFilter[]{new InputFilterMinMax("0", "999")});

            qty2_edit = dialog_view.findViewById(R.id.qty2_edit);
            qty2_edit.setFilters(new InputFilter[]{new InputFilterMinMax("0", "999")});

            qty3_edit = dialog_view.findViewById(R.id.qty3_edit);
            qty3_edit.setFilters(new InputFilter[]{new InputFilterMinMax("0", "999")});

            //enable qty controls for set prices only
            qty1_edit.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    computeOrderPrice(origFood);
                }
            });

            qty2_edit.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    computeOrderPrice(origFood);
                }
            });

            qty3_edit.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    computeOrderPrice(origFood);
                }
            });

            LinearLayout qty_controls1 = dialog_view.findViewById(R.id.qty_controls1);
            if(origFood.price1 == 0 || origFood.stock1 < 1){
                price1.setText("Out of stock");
                price1.setTextSize(10f);
                qty_controls1.setVisibility(View.INVISIBLE);
            }
            else {
                price1.setText("₱" + origFood.price1);
                price1.setTextSize(18f);
                qty_controls1.setVisibility(View.VISIBLE);
                dialog_view.findViewById(R.id.up_qty1).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Log.d(TAG, qty1_edit.getText().toString());
                        modifyQtyValue(v);

                        computeOrderPrice(origFood);
                    }
                });

                dialog_view.findViewById(R.id.down_qty1).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        modifyQtyValue(v);

                        computeOrderPrice(origFood);
                    }
                });
            }

            LinearLayout qty_controls2 = dialog_view.findViewById(R.id.qty_controls2);
            if(origFood.price2 == 0 || origFood.stock2 < 1) {
                price2.setText("Out of stock");
                price2.setTextSize(10f);
                qty_controls2.setVisibility(View.INVISIBLE);
            }
            else {
                price2.setText("₱" + origFood.price2);
                price2.setTextSize(18f);
                qty_controls2.setVisibility(View.VISIBLE);

                dialog_view.findViewById(R.id.up_qty2).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        modifyQtyValue(v);

                        computeOrderPrice(origFood);
                    }
                });

                dialog_view.findViewById(R.id.down_qty2).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        modifyQtyValue(v);

                        computeOrderPrice(origFood);
                    }
                });
            }

            LinearLayout qty_controls3 = dialog_view.findViewById(R.id.qty_controls3);
            if(origFood.price3 == 0 || origFood.stock3 < 1) {
                price3.setText("Out of stock");
                price3.setTextSize(10f);
                qty_controls3.setVisibility(View.INVISIBLE);
            }
            else {
                price3.setText("₱" + origFood.price3);
                price3.setTextSize(18f);
                qty_controls3.setVisibility(View.VISIBLE);

                dialog_view.findViewById(R.id.up_qty3).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        modifyQtyValue(v);

                        computeOrderPrice(origFood);
                    }
                });

                dialog_view.findViewById(R.id.down_qty3).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        modifyQtyValue(v);

                        computeOrderPrice(origFood);
                    }
                });
            }


            alert.setOnShowListener(new DialogInterface.OnShowListener() {
                @Override
                public void onShow(DialogInterface dialog) {
                    final Button positiveButton = alert.getButton(AlertDialog.BUTTON_POSITIVE);
                    final Button negativeButton = alert.getButton(AlertDialog.BUTTON_NEGATIVE);


                    positiveButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            QuantityPrices quantityPrices = new QuantityPrices(
                                    Integer.parseInt(qty1_edit.getText().toString()),
                                    Integer.parseInt(qty2_edit.getText().toString()),
                                    Integer.parseInt(qty3_edit.getText().toString()));

                            final CartItem newCartItem = new CartItem(food_name_edit.getText().toString(), quantityPrices);
                            final String editedUID = newCartItem.item_name.toLowerCase().trim().replaceAll(" +", " ").replaceAll(" ", "_");

                            final FirebaseDatabase database = FirebaseDatabase.getInstance();
                            //check qty of food to order
                            final DatabaseReference foodCheckRef = database.getReference("foods/" + editedUID);

                            foodCheckRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    final Food food_to_check = dataSnapshot.getValue(Food.class);

                                    if (food_to_check != null)
                                    {
                                        loading_dialog_constraint.setVisibility(View.VISIBLE);
                                        positiveButton.setEnabled(false);
                                        negativeButton.setEnabled(false);

                                        //check if all qty have atleast a value
                                        if (getEditTextIntValue(qty1_edit) == 0 && getEditTextIntValue(qty2_edit) == 0 && getEditTextIntValue(qty3_edit) == 0) {
                                            showToast("Please enter quantity value!");
                                            loading_dialog_constraint.setVisibility(View.GONE);
                                            positiveButton.setEnabled(true);
                                            negativeButton.setEnabled(true);
                                            return;
                                        }
                                        //try to add item on cart

                                        final FirebaseDatabase database = FirebaseDatabase.getInstance();
                                        final DatabaseReference myRef = database.getReference("users/" + MainActivity.loggedUser.getUserId() + "/cart/" + editedUID);

                                        //get the same existing cart item
                                        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot cartItem) {
                                                String stock_lack_message = "";
                                                String tailMessage = "";

                                                //if item already exist on cart
                                                if (cartItem.exists()) {
                                                    //then add new selected qty
                                                    CartItem existingCartItem = cartItem.getValue(CartItem.class);

                                                    newCartItem.myQtys.qty1 += existingCartItem.myQtys.qty1;
                                                    if(existingCartItem.myQtys.qty1 > 0)
                                                        tailMessage +=  existingCartItem.myQtys.qty1 + " Small,";
                                                    newCartItem.myQtys.qty2 += existingCartItem.myQtys.qty2;
                                                    if(existingCartItem.myQtys.qty2 > 0)
                                                        tailMessage +=  existingCartItem.myQtys.qty2 + " Medium,";
                                                    newCartItem.myQtys.qty3 += existingCartItem.myQtys.qty3;
                                                    if(existingCartItem.myQtys.qty3 > 0)
                                                        tailMessage +=  existingCartItem.myQtys.qty3 + " Large.";
                                                }

                                                if (food_to_check.getStock1() < newCartItem.myQtys.qty1)
                                                    stock_lack_message += food_to_check.getStock1() + " Small,";

                                                if (food_to_check.getStock2() < newCartItem.myQtys.qty2)
                                                    stock_lack_message += food_to_check.getStock2() + " Medium,";

                                                if (food_to_check.getStock3() < newCartItem.myQtys.qty3)
                                                    stock_lack_message += food_to_check.getStock3() + " Large.";

                                                if(stock_lack_message.length() == 0) {
                                                    myRef.setValue(newCartItem).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<Void> task) {
                                                            showToast("Item successfully added to your cart");
                //                                            loading_dialog_constraint.setVisibility(View.GONE);
                //                                            positiveButton.setClickable(true);
                //                                            negativeButton.setClickable(true);

                                                            alert.dismiss();
                                                        }
                                                    });
                                                }
                                                else
                                                {
                                                    if(tailMessage.length() > 0)
                                                    {
                                                        tailMessage = "Your cart already contains : " + tailMessage.substring(0, tailMessage.length()-1);
                                                    }
                                                    showAlert(stock_lack_message, food_to_check.getFood_name(), tailMessage);
                                                    loading_dialog_constraint.setVisibility(View.GONE);
                                                    positiveButton.setEnabled(true);
                                                    negativeButton.setEnabled(true);
                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                            }
                                        });
                                    }
                                    else
                                    {
                                        AlertDialog.Builder b = new AlertDialog.Builder(MainActivity.context).setCancelable(false);

                                        AlertDialog a = b.setMessage("Item doesn't exists!").setTitle("Error").setPositiveButton("Ok", null).create();
                                        a.show();
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }
                    });

                    negativeButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Log.d(TAG, "cancel cart dialog button");
                            alert.dismiss();
                        }
                    });
                }
            });

        }

        //override dismiss

        alert.show();
    }

    private void showAlert(String stock_lack_message, String food_name, String tailMessage)
    {
        stock_lack_message = "Sorry, "+ food_name + " insufficient stock, " + stock_lack_message.substring(0, stock_lack_message.length()-1) + " available." + tailMessage;
        AlertDialog.Builder b = new AlertDialog.Builder(MainActivity.context).setCancelable(false);

        AlertDialog a = b.setMessage(stock_lack_message).setTitle("Item insufficient stock").setPositiveButton("Ok", null).create();
        a.show();
    }

    private void computeOrderPrice(Food food)
    {
        if(food != null) {
            int orderPrice = (food.price1 * getEditTextIntValue(qty1_edit)) + (food.price2 * getEditTextIntValue(qty2_edit)) + (food.price3 * getEditTextIntValue(qty3_edit));
            order_price_label.setText("Order Price : ₱" + orderPrice);
        }
    }

    public void modifyQtyValue(View view)
    {
        switch (view.getId())
        {
            case R.id.up_qty1 :
                int addVal1 = 0;
                if(!qty1_edit.getText().toString().isEmpty())
                    addVal1 = Math.max(0, Integer.parseInt(qty1_edit.getText().toString()) + 1);
                qty1_edit.setText(String.valueOf(addVal1));break;
            case R.id.up_qty2 :  int addVal2 = 0;
                if(!qty2_edit.getText().toString().isEmpty())
                    addVal2 = Math.max(0, Integer.parseInt(qty2_edit.getText().toString()) + 1);
                qty2_edit.setText(String.valueOf(addVal2));break;
            case R.id.up_qty3 :  int addVal3 = 0;
                if(!qty3_edit.getText().toString().isEmpty())
                    addVal3 = Math.max(0, Integer.parseInt(qty3_edit.getText().toString()) + 1);
                qty3_edit.setText(String.valueOf(addVal3));break;



            case R.id.down_qty1 :
                int subVal1 = 0;
                if(!qty1_edit.getText().toString().isEmpty())
                    subVal1 = Math.max(0, Integer.parseInt(qty1_edit.getText().toString()) - 1);
                qty1_edit.setText(String.valueOf(subVal1));break;
            case R.id.down_qty2 :
                int subVal2 = 0;
                if(!qty2_edit.getText().toString().isEmpty())
                    subVal2 = Math.max(0, Integer.parseInt(qty2_edit.getText().toString()) - 1);
                qty2_edit.setText(String.valueOf(subVal2));break;

            case R.id.down_qty3 :
                int subVal3 = 0;
                if(!qty3_edit.getText().toString().isEmpty())
                    subVal3 = Math.max(0, Integer.parseInt(qty3_edit.getText().toString()) - 1);
                qty3_edit.setText(String.valueOf(subVal3));break;
        }
    }

    private int getEditTextIntValue(EditText edit)
    {
        int retVal = 0;

        if(!edit.getText().toString().isEmpty())
            retVal = Integer.parseInt(edit.getText().toString());

        return retVal;
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {

            Uri uri = data.getData();


            String realPath = ImageFilePath.getPath(MainActivity.context, data.getData());
//                realPath = RealPathUtil.getRealPathFromURI_API19(this, data.getData());

            Log.i(TAG, "onActivityResult: file path : " + realPath);
            //Bitmap bitmap = BitmapFactory.decodeFile(realPath);

            Log.d(TAG, realPath);

            Bitmap bm = BitmapFactory.decodeFile(realPath);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG, 90, baos); //bm is the bitmap object
            byte[] b = baos.toByteArray();

            selectedImageString = Base64.encodeToString(b, Base64.DEFAULT);

            Log.d(TAG, selectedImageString);

            ImageView food_image = dialog_view.findViewById(R.id.food_image_edit);
            if(food_image!= null) {
                food_image.setImageBitmap(bm);
            }


        } else {
            if(requestCode == PICK_IMAGE_REQUEST) {
                //selectedImageString = "";
                if (resultCode != RESULT_CANCELED) {
                    Toast.makeText(MainActivity.context, "Something Went Wrong", Toast.LENGTH_LONG).show();
                }
            }
        }


    }

    //then get all food and place it in their category
    private void getFoodListFromDB()
    {
        //HashMap<String, List<String>> food_catalog = new HashMap<String, List<String>>();

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference myRef = database.getReference("foods");

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot foods) {
                if(foods.exists()) {
                    int i = 0;

                    //MainActivity.food_catalog = new ArrayList<>();

                    for (DataSnapshot food: foods.getChildren()){
                        //place this food in it's designated category
                        String thisFoodCategory = food.child("category").getValue(String.class);
                        Food thisFood = food.getValue(Food.class);

                        thisFood.uid = food.getKey();
                        if(MainActivity.food_catalog.containsKey(thisFoodCategory))
                        {
                            MainActivity.food_catalog.get(thisFoodCategory).add(thisFood);
                        }
                        else//if food category doesn't exist or deleted, put it in Uncategorized
                        {
                            MainActivity.food_catalog.get("Uncategorized").add(thisFood);
                        }

                        Log.d(TAG, "Before image : " + thisFood.image);

                        Food food_no_image = (Food) thisFood.clone();
                        food_no_image.image = "";
                        //thisFood.image = "";//we don't include the image because parceable has a limit of 1MB
                        MainActivity.foodByName.put(thisFood.uid, food_no_image);

                        //MainActivity.food_catalog.add(food.getValue(Food.class));
                        i++;

                        if(i >= foods.getChildrenCount())
                        {
                            generateFoodViews();
                        }
                    }
                }
                else
                {
                    showLoading(false);
                    attachNewItemFabListener();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        //food_catalog = ExpandableListDataPump.getData();

    }

    //then create view representations
    private void generateFoodViews()
    {
        showLoading(false);
        expandableListTitle = new ArrayList<>(MainActivity.food_catalog.keySet());
        expandableListAdapter = new CustomExpandableListAdapter(MainActivity.context, expandableListTitle, MainActivity.food_catalog, this);
        expandableListView.setAdapter(expandableListAdapter);
        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {
//                Toast.makeText(MainActivity.context,
//                        expandableListTitle.get(groupPosition) + " List Expanded.",
//                        Toast.LENGTH_SHORT).show();
            }
        });

        expandableListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

            @Override
            public void onGroupCollapse(int groupPosition) {
//                Toast.makeText(MainActivity.context,
//                        expandableListTitle.get(groupPosition) + " List Collapsed.",
//                        Toast.LENGTH_SHORT).show();

            }
        });



        attachNewItemFabListener();

//        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
//            @Override
//            public boolean onChildClick(ExpandableListView parent, View v,
//                                        int groupPosition, int childPosition, long id) {
//                Toast.makeText(
//                        MainActivity.context,
//                        expandableListTitle.get(groupPosition)
//                                + " -> "
//                                + food_catalog.get(
//                                expandableListTitle.get(groupPosition)).get(
//                                childPosition).food_name, Toast.LENGTH_LONG
//                ).show();
//                return false;
//            }
//        });
    }
}