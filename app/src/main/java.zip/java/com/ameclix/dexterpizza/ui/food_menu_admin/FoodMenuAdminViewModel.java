package com.ameclix.dexterpizza.ui.food_menu_admin;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class FoodMenuAdminViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public FoodMenuAdminViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is food menu ADMIN fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}