package com.ameclix.dexterpizza.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.ameclix.dexterpizza.MainActivity;
import com.ameclix.dexterpizza.R;
import com.ameclix.dexterpizza.data.model.Order;
import com.ameclix.dexterpizza.ui.orders.OrderViewActivity;
import com.ameclix.dexterpizza.ui.orders.OrdersFragment;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class OrderAdapter extends ArrayAdapter<Order> {

    public final String TAG = "myLogTag";
    private OrdersFragment ordersFragment;


    public OrderAdapter(@NonNull Context context, ArrayList<Order> order_items, OrdersFragment ordersFragment) {
        super(context, 0, order_items);
        this.ordersFragment = ordersFragment;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(MainActivity.context).inflate(R.layout.order_entry, parent, false);
        }



        TextView order_num = convertView.findViewById(R.id.order_number);
        TextView order_items = convertView.findViewById(R.id.order_items);
        TextView order_total_price = convertView.findViewById(R.id.order_total_price);
        TextView order_status = convertView.findViewById(R.id.order_status);
        TextView order_quantity = convertView.findViewById(R.id.order_quantity);
        TextView order_date = convertView.findViewById(R.id.order_date);
        LinearLayout order_entry_parent = convertView.findViewById(R.id.order_entry_parent);

        final Order thisOrder = getItem(position);
        convertView.setTag(thisOrder);

        Log.d(TAG, "Hello " + thisOrder.orderNumber);

        //fill up fields
        String formatted_order_num = String.format("%04d", thisOrder.orderNumber);
        order_num.setText(formatted_order_num);
        order_items.setText(""+thisOrder.order_carts.size());
        order_total_price.setText("₱"+thisOrder.total_price);
        order_status.setText(ordersFragment.orderStateStrings[thisOrder.state]);
        order_quantity.setText(String.valueOf(thisOrder.getTotalQuantity()));

        if(thisOrder.state == 0)
            order_date.setText(thisOrder.date_checkout);
        else
            order_date.setText(thisOrder.last_date_processed);


        order_entry_parent.setTag(thisOrder);
        order_entry_parent.setOnClickListener(order_click_listener);

        //attach delete_order_admin callback
        if(thisOrder.state == 3)
        {
            ImageView delete_order_admin = convertView.findViewById(R.id.delete_order_admin);
            delete_order_admin.setVisibility(View.VISIBLE);
            delete_order_admin.setTag(thisOrder);
            delete_order_admin.setOnClickListener(delete_order_listener);
        }

        return convertView;
    }

    final View.OnClickListener delete_order_listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            final Order selectedOrder = (Order) v.getTag();

            DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    switch (which){
                        case DialogInterface.BUTTON_POSITIVE:
                            FirebaseDatabase database = FirebaseDatabase.getInstance();
                            DatabaseReference myRef = database.getReference("orders/" + selectedOrder.getUid());

                            myRef.removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    ordersFragment.showToast("Order# "+ String.format("%04d", selectedOrder.orderNumber) + " successfully deleted");
                                    ordersFragment.removeCachedOrder(selectedOrder.getUid());
                                    ordersFragment.setOrderFilter(3);
                                }
                            });

//                            notifyDataSetChanged();
                            break;

                        case DialogInterface.BUTTON_NEGATIVE:
                            //No button clicked
                            Log.d("myLogTag","You clicked cancel!");
                            break;
                    }
                }
            };


            String theMessage = "Are you sure you want to delete the Order #" +  String.format("%04d", selectedOrder.orderNumber) + "?";
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.context);
            //dialog_view = LayoutInflater.from(MainActivity.context).inflate(R.layout.dialog_input, null);
            builder.setTitle("Confirm Delete").setMessage(theMessage).setPositiveButton("Yes", dialogClickListener)
                    .setNegativeButton("No", dialogClickListener).show();
        }
    };

    final View.OnClickListener order_click_listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {


            final Order selected_order = (Order) v.getTag();

            Intent intent = new Intent(MainActivity.context, OrderViewActivity.class);
            intent.putExtra("SelectedOrder", selected_order);

            MainActivity.instance.startActivityForResult(intent, 69);
        }
    };

}
