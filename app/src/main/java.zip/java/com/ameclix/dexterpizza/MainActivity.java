package com.ameclix.dexterpizza;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.NavGraph;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.ameclix.dexterpizza.data.model.Food;
import com.ameclix.dexterpizza.data.model.LoggedInUser;
import com.ameclix.dexterpizza.ui.login.LoginActivity;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public final String TAG = "myLogTag";
    private AppBarConfiguration mAppBarConfiguration;
    private String adminName;
    public static boolean isAdmin = false;
    public static LoggedInUser loggedUser;
//    private FloatingActionButton cart_fab;
    private DrawerLayout drawer;
    private NavigationView navigationView;
    public static Context context;
    public static HashMap<String, List<Food>> food_catalog;
    public static HashMap<String, Food> foodByName;

    public static MainActivity instance;
    public static NavController navController;

    public String passwordEntered;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        navigationView = findViewById(R.id.nav_view);

        context = this;
        instance = this;

        getAdminCredentials();

        //isAdmin = getIntent().getBooleanExtra("isAdmin", false);

        loggedUser = LoginActivity.myUser;

        Toolbar toolbar = findViewById(R.id.cart_toolbar);
        setSupportActionBar(toolbar);

        foodByName = new HashMap<>();
//        cart_fab = findViewById(R.id.fab);

        if (savedInstanceState != null) {
            ArrayList<Food> values = savedInstanceState.getParcelableArrayList("savedFoodData");

            for (Food f : values) {
                foodByName.put(f.uid, f);
            }
        }

        Intent intent = getIntent();
        passwordEntered = intent.getStringExtra("passwordEntered");
        checkIfPasswordMatched();
    }

    private void checkIfPasswordMatched() {
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("admin");
    }

    public Food getFoodInfo(String category, String uid)
    {
//        Food retVal = null;
        for (Food f: food_catalog.get(category)) {
            if (f.uid.equals(uid))
                return f;
        }

        return null;
    }


    public void onSaveInstanceState(Bundle savedState) {

        super.onSaveInstanceState(savedState);

        // Note: getValues() is a method in your ArrayAdapter subclass
        ArrayList<Food> values = new ArrayList<Food>(foodByName.values());
        savedState.putParcelableArrayList("savedFoodData", values);
    }


    @Override
    protected void onStart() {
        super.onStart();
        //This checks for the permission
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
        {
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.READ_EXTERNAL_STORAGE)){


                // You can show your dialog message here but instead I am
                // showing the grant permission dialog box
                ActivityCompat.requestPermissions(this, new String[] {
                                Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE },
                        10);



            }
            else{

                //Requesting permission
                ActivityCompat.requestPermissions(this, new String[] {
                                Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE },
                        10);
            }
        }
    }

    private void setAdminStuff()
    {
//        cart_fab.setVisibility(View.GONE);

        drawer = findViewById(R.id.drawer_layout);

        navigationView.inflateMenu(R.menu.activity_admin_drawer);

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_orders_admin, R.id.nav_food_menu_admin, R.id.nav_categories,
                R.id.nav_profile)
                .setDrawerLayout(drawer)
                .build();

        navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavGraph navGraph = navController.getNavInflater().inflate(R.navigation.admin_navigation);
        navController.setGraph(navGraph);

        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
        //navigationView.setNavigationItemSelectedListener(this);



        navigationView.getMenu().getItem(navigationView.getMenu().size()-1).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                logout();
                return false;
            }
        });
    }

    public void showDialog(String title, String msg)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.context);
        builder.setTitle(title).setMessage(msg).show();
    }

    private void setClientStuff()
    {
//        cart_fab.setVisibility(View.VISIBLE);



        drawer = findViewById(R.id.drawer_layout);

        navigationView.inflateMenu(R.menu.activity_client_drawer);

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_food_menu_admin, R.id.nav_my_orders, R.id.nav_cart,
                R.id.nav_profile)
                .setDrawerLayout(drawer)
                .build();



        navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavGraph navGraph = navController.getNavInflater().inflate(R.navigation.client_navigation);
        navController.setGraph(navGraph);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
        //navigationView.setNavigationItemSelectedListener(this);

        navigationView.getMenu().getItem(navigationView.getMenu().size()-1).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                logout();
                return false;
            }
        });

//        cart_fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                CartFragment newCartFragment = new CartFragment();
//                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
//                fragmentTransaction.replace(R.id.nav_host_fragment, newCartFragment);
//                fragmentTransaction.addToBackStack(null);
//                fragmentTransaction.commit();
//            }
//        });
    }

    private void getAdminCredentials() {
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("admin");

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    adminName = dataSnapshot.child("email").getValue(String.class);
                    //adminPass = dataSnapshot.child("password").getValue(String.class);
                    assert adminName != null;
                    isAdmin = (adminName.equals(loggedUser.getEmail()));
                }

                if(isAdmin)
                    setAdminStuff();
                else
                    setClientStuff();

                String aaaa = (isAdmin)? "yes" : "no";
                Log.d(TAG, "isAdmin " +  aaaa);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    public void logout()
    {
        isAdmin = false;
        loggedUser = null;
        FirebaseAuth.getInstance().signOut();
        Intent i = new Intent(this, LoginActivity.class);
        startActivity(i);
        finish();
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
//        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                switch (which){
//                    case DialogInterface.BUTTON_POSITIVE:
//                        //Yes button clicked
//                        FirebaseAuth.getInstance().signOut();
//                        MainActivity.super.onBackPressed();
//                        break;
//
//                    case DialogInterface.BUTTON_NEGATIVE:
//                        //No button clicked
//                        break;
//                }
//            }
//        };

        //Log.d(TAG, getCallerFragment());
//        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
//        builder.setMessage("Are you sure you want to log out?").setPositiveButton("Yes", dialogClickListener)
//                .setNegativeButton("No", dialogClickListener).show();
    }

    public static void showToast(String message){
        Toast.makeText(MainActivity.context, message, Toast.LENGTH_LONG).show();
    }
}
