package com.ameclix.dexterpizza.adapters;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ameclix.dexterpizza.MainActivity;
import com.ameclix.dexterpizza.R;
import com.ameclix.dexterpizza.data.model.CartItem;
import com.ameclix.dexterpizza.data.model.Food;

import java.util.ArrayList;
import java.util.List;

public class OrderCartAdapter extends ArrayAdapter<CartItem> {
    public final String TAG = "myLogTag";
//    private OrdersFragment ordersFragment;
    private List<CartItem> myCartItems = new ArrayList<>();
    private LayoutInflater inflater;
    private Activity activity;

    public OrderCartAdapter(@NonNull Context context, List<CartItem> myCartItems, Activity activity) {
        super(context, 0, myCartItems);

//        this.ordersFragment = ordersFragment;
        this.activity = activity;
        this.myCartItems = myCartItems;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if (inflater == null)
            inflater = (LayoutInflater) activity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

// Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.order_cart_entry, parent, false);
        }

        final CartItem thisCartItem = getItem(position);

        TextView txt_order_cart_name = convertView.findViewById(R.id.txt_order_cart_name);
        TextView txt_order_cart_qtys = convertView.findViewById(R.id.txt_order_cart_qtys);
        TextView txt_order_cart_total = convertView.findViewById(R.id.txt_order_cart_total);
        ImageView order_cart_item_image = convertView.findViewById(R.id.order_cart_item_image);

        txt_order_cart_name.setText(thisCartItem.item_name);

        String qty_text = "x"+thisCartItem.myQtys.qty1 + " small";
        if(thisCartItem.myQtys.qty2 > 0)
            qty_text += ", x" + thisCartItem.myQtys.qty2 + " medium";
        if(thisCartItem.myQtys.qty3 > 0)
            qty_text += ", x" + thisCartItem.myQtys.qty3 + " large";

        txt_order_cart_qtys.setText(qty_text);

        Food food = MainActivity.foodByName.get(thisCartItem.getItem_id());

        if(food != null) {
            Food food_with_image = MainActivity.instance.getFoodInfo(food.category, food.uid);

            if(food_with_image != null){
                String string_image = food_with_image.image;
                Log.d(TAG, "image of food " + food.food_name + " is : " + string_image);

                if (string_image.trim().length() > 0) {
                    byte[] decodedString = Base64.decode(string_image, Base64.DEFAULT);
                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                    order_cart_item_image.setImageBitmap(decodedByte);
                }
            }



            int total = (thisCartItem.myQtys.qty1 * food.price1) + (thisCartItem.myQtys.qty2 * food.price2) + (thisCartItem.myQtys.qty3 * food.price3);
            //Log.d(TAG, "total : " + total);
            txt_order_cart_total.setText("₱" + total);
        }

        Log.d(TAG, "Hi");

        return convertView;
    }
}