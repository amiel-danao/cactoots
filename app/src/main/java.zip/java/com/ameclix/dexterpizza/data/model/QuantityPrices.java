package com.ameclix.dexterpizza.data.model;

import java.io.Serializable;

public class QuantityPrices implements Serializable {
    public int qty1 = 0, qty2 = 0, qty3 = 0;

    public QuantityPrices(){}

    public QuantityPrices(int qty1, int qty2, int qty3) {
        this.qty1 = qty1;
        this.qty2 = qty2;
        this.qty3 = qty3;
    }

    public int getQty1() {
        return qty1;
    }

    public void setQty1(int qty1) {
        this.qty1 = qty1;
    }

    public int getQty2() {
        return qty2;
    }

    public void setQty2(int qty2) {
        this.qty2 = qty2;
    }

    public int getQty3() {
        return qty3;
    }

    public void setQty3(int qty3) {
        this.qty3 = qty3;
    }



}
