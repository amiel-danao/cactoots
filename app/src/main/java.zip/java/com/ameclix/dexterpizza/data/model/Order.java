package com.ameclix.dexterpizza.data.model;

import java.io.Serializable;
import java.util.List;

public class Order implements Serializable {
    public String uid, person_uid, person_name, address, phone;
    public List<CartItem> order_carts;
    public int total_price;
    public String date_checkout, last_date_processed;
    public int state;
    public int orderNumber;

    public Order(){};

    public Order(String uid, String person_uid, String person_name, String address, String phone, List<CartItem> order_carts, int total_price, String date_checkout, String last_date_processed, int state, int orderNumber) {
        this.uid = uid;
        this.person_uid = person_uid;
        this.person_name = person_name;
        this.address = address;
        this.phone = phone;
        this.order_carts = order_carts;
        this.total_price = total_price;
        this.date_checkout = date_checkout;
        this.last_date_processed = last_date_processed;
        this.state = state;
        this.orderNumber = orderNumber;
    }

    public int getTotalQuantity()
    {
        int retVal = 0;
        for (CartItem cartItem: order_carts) {
            retVal += cartItem.myQtys.getQty1() + cartItem.myQtys.getQty2() + cartItem.myQtys.getQty3();
        }

        return retVal;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPerson_name() {
        return person_name;
    }

    public void setPerson_name(String person_name) {
        this.person_name = person_name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public List<CartItem> getOrder_carts() {
        return order_carts;
    }

    public void setOrder_carts(List<CartItem> order_carts) {
        this.order_carts = order_carts;
    }

    public int getTotal_price() {
        return total_price;
    }

    public void setTotal_price(int total_price) {
        this.total_price = total_price;
    }

    public String getDate_checkout() {
        return date_checkout;
    }

    public void setDate_checkout(String date_checkout) {
        this.date_checkout = date_checkout;
    }

    public String getLast_date_processed() {
        return last_date_processed;
    }

    public void setLast_date_processed(String last_date_processed) {
        this.last_date_processed = last_date_processed;
    }
}
