package com.ameclix.dexterpizza.ui.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.util.Patterns;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.ameclix.dexterpizza.MainActivity;
import com.ameclix.dexterpizza.R;
import com.ameclix.dexterpizza.data.model.LoggedInUser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends AppCompatActivity {



    public final String TAG = "myLogTag";
    private LoginViewModel loginViewModel;
    public static FirebaseAuth mAuth;
    public static LoginActivity instance;
    //my login ui
    private EditText password_field, confirm_password_field, email_field;
    private ImageView logo_image;
    private ConstraintLayout login_layout, register_layout, loadingProgressBar;
    private Button registerButton;
    private List<EditText> requiredFields;
    private EditText fname, lname, phone, address;
    public static LoggedInUser myUser;
    private View dialog_view;


    private String adminName, adminPass;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        instance = this;

        loginViewModel = ViewModelProviders.of(this, new LoginViewModelFactory())
                .get(LoginViewModel.class);

        final EditText usernameEditText = findViewById(R.id.email_login_edit);
        final EditText passwordEditText = findViewById(R.id.password);
        final Button loginButton = findViewById(R.id.login);
        //final ProgressBar loadingProgressBar = findViewById(R.id.loading);

        //my register ui
        email_field = findViewById(R.id.email_field);
        password_field = findViewById(R.id.password_field);
        confirm_password_field = findViewById(R.id.password_confirm_field);


        login_layout = findViewById(R.id.login_constraint);
        register_layout = findViewById(R.id.register_constraint);
        loadingProgressBar = findViewById(R.id.loading_constraint);
        registerButton = findViewById(R.id.save_profile_button);

        //required register fields
        requiredFields = new ArrayList<>();
        fname = findViewById(R.id.first_name);
        requiredFields.add(fname);
        lname = findViewById(R.id.last_name);
        requiredFields.add(lname);
        phone = findViewById(R.id.phone_field);
        requiredFields.add(phone);
        address = findViewById(R.id.address_field);
        requiredFields.add(address);

        TextView recoveryLink = findViewById(R.id.recovery_link);
                recoveryLink.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showRecovery();
                    }
                });

        CheckBox debug_admin_box = findViewById(R.id.debug_admin_box);



        debug_admin_box.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // update your model (or other business logic) based on isChecked
                Log.d(TAG, isChecked? "true": "false");
                if(isChecked)
                    usernameEditText.setText("admin@email.com");
                else
                    usernameEditText.setText("amiel.danao@yahoo.com");
            }
        });

        //clear login field if not admin test build
        if(debug_admin_box.getVisibility() == View.GONE)
        {
            usernameEditText.setText("");
            passwordEditText.setText("");
        }


        getAdminCredentials();
        mAuth = FirebaseAuth.getInstance();

        loginButton.setEnabled(true);
        loginViewModel.getLoginFormState().observe(this, new Observer<LoginFormState>() {
            @Override
            public void onChanged(@Nullable LoginFormState loginFormState) {
                if (loginFormState == null) {
                    return;
                }
                loginButton.setEnabled(loginFormState.isDataValid());
                if (loginFormState.getUsernameError() != null) {
                    usernameEditText.setError(getString(loginFormState.getUsernameError()));
                }
                if (loginFormState.getPasswordError() != null) {
                    passwordEditText.setError(getString(loginFormState.getPasswordError()));
                }
            }
        });


        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                loginViewModel.loginDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());
            }
        };

        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    loginViewModel.login(usernameEditText.getText().toString(),
                            passwordEditText.getText().toString());
                }
                return false;
            }
        });



        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadingProgressBar.setVisibility(View.VISIBLE);
//                loginViewModel.login(usernameEditText.getText().toString(),
//                        passwordEditText.getText().toString());

                //then validate email and password
                if (loginDataChanged(usernameEditText.getText().toString(), passwordEditText.getText().toString())) {
                    signInWithFirebase(usernameEditText.getText().toString(), passwordEditText.getText().toString());

                }
                else
                {
                    loadingProgressBar.setVisibility(View.GONE);
                }
            }
        });
        

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadingProgressBar.setVisibility(View.VISIBLE);
                //check all required fields first
                EditText invalidRequiredField = isValidInputFieldsRequired(requiredFields);
                if(invalidRequiredField == null) {
                    //then validate email and password
                    if (registerDataChanged(email_field.getText().toString(), password_field.getText().toString(), confirm_password_field.getText().toString())) {
                        createUser(email_field.getText().toString(), password_field.getText().toString());
                        loadingProgressBar.setVisibility(View.GONE);
                    }
                    else
                    {
                        loadingProgressBar.setVisibility(View.GONE);
                    }
                }
                else
                {
                    invalidRequiredField.setError("This field is required!");
                    loadingProgressBar.setVisibility(View.GONE);
                }
            }
        });

        if (savedInstanceState != null) {
            boolean isRegistrationForm = savedInstanceState.getBoolean("registerForm");
            if (isRegistrationForm)
            {
                login_layout.setVisibility(View.GONE);
                register_layout.setVisibility(View.VISIBLE);
            }
            else
            {
                register_layout.setVisibility(View.GONE);
                login_layout.setVisibility(View.VISIBLE);
            }
        }
    }

    public void onSaveInstanceState(Bundle savedState) {

        super.onSaveInstanceState(savedState);

        savedState.putBoolean("registerForm", (register_layout.getVisibility() == View.VISIBLE? true : false));

    }

    private void getAdminCredentials() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("admin");

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    adminName = dataSnapshot.child("email").getValue(String.class);
                    adminPass = dataSnapshot.child("password").getValue(String.class);
                    Log.d(TAG, "Admin Info Exists!");
                    Log.d(TAG, "pass = " + adminPass);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    private void gotoMain(boolean admin)
    {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("isAdmin", admin);
        startActivity(i);

        finish();
    }

    private void updateNewUserToDB(FirebaseUser user)
    {
        LoggedInUser newUser = new LoggedInUser();

        newUser.setEmail(user.getEmail());
        newUser.setPassword(password_field.getText().toString());
        newUser.setFirst_name(fname.getText().toString());
        newUser.setLast_name(lname.getText().toString());
        newUser.setPhone(phone.getText().toString());
        newUser.setAddress(address.getText().toString());


        DatabaseReference mRef = FirebaseDatabase.getInstance().getReference("users");
        mRef.child(user.getUid()).setValue(newUser);
        updateUI(user);
        gotoMain(false);
    }

    private void createUser(String email, String password)
    {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            showToast("Welcome " + fname.getText().toString());
                            FirebaseUser user = mAuth.getCurrentUser();

                            user.sendEmailVerification()
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                showToast("Email Verification sent.");
                                            }
                                        }
                                    });

                            updateNewUserToDB(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "createUserWithEmail:failure", task.getException());
                            showToast(task.getException().getMessage());
                            //updateUI(null);
                        }
                    }
                });
    }

    private void updateUI(FirebaseUser user)
    {
        if(user == null) {
            myUser = null;
            return;
        }

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("users/" + user.getUid());
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    myUser = dataSnapshot.getValue(LoggedInUser.class);
                    myUser.setUserId(dataSnapshot.getKey());

                    gotoMain(false);
                }
                else
                {
                    showToast("User doesn't exist!");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }



    public void signInWithFirebase(final String email, final String password)
    {
        if(email.equals(adminName) && password.equals(adminPass))
        {
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("admin");

            try {

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot admin) {
                        if(admin.exists())
                        {
                            myUser = new LoggedInUser();
                            myUser.setFirst_name(admin.child("first_name").getValue(String.class));
                            myUser.setLast_name(admin.child("last_name").getValue(String.class));
                            myUser.setAddress(admin.child("address").getValue(String.class));
                            myUser.setPhone(admin.child("phone").getValue(String.class));
                            myUser.setPassword(admin.child("password").getValue(String.class));
                            myUser.setEmail(admin.child("email").getValue(String.class));

                            gotoMain(true);
                            loadingProgressBar.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        showToast(databaseError.getMessage());
                    }
                });
            }
            catch (Exception e)
            {
                showToast(e.getMessage());
            }
        }
        else {

            try {
                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information

                                    FirebaseUser user = mAuth.getCurrentUser();
                                    //showToast("Welcome " + );
                                    updateUI(user);
                                } else {
                                    // If sign in fails, display a message to the user.
                                    //Log.w(TAG, "signInWithEmail:failure", task.getException());
                                    showToast(task.getException().getMessage());

                                    //updateUI(null);
                                }
                                loadingProgressBar.setVisibility(View.GONE);
                                // ...
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        showToast(e.getMessage());
                    }
                });
            }
            catch (Exception e)
            {
                showToast(e.getMessage());
            }
        }

    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null)
            mAuth.signOut();
        //updateUI(currentUser);
    }



    public EditText isValidInputFieldsRequired(List<EditText> fields){
        EditText result = null;
        for (EditText field: fields) {
            if(field.getText().toString().trim().isEmpty()) {
                //showToast("Please fill all required fields!");
                return field;
            }
        }
        return result;
    }

    private void updateUiWithUser(LoggedInUserView model) {
        String welcome = getString(R.string.welcome) + model.getDisplayName();
        // TODO : initiate successful logged in experience
        Toast.makeText(getApplicationContext(), welcome, Toast.LENGTH_LONG).show();
    }

    private void showLoginFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }

    public boolean loginDataChanged(String username, String password) {
        if (!isUserNameValid(username)) {
            email_field.setError("Invalid email");//showToast("Invalid email!");
            return false;
            //loginFormState.setValue(new LoginFormState(R.string.invalid_username, null));
        } else if (!isPasswordValid(password)) {
            //showToast("Invalid password must be 5> characters!");
            password_field.setError("Invalid password!");
            return false;
            //loginFormState.setValue(new LoginFormState(null, R.string.invalid_password));
        }
        else {
            //loginFormState.setValue(new LoginFormState(true));
            return true;
        }
    }

    public boolean registerDataChanged(String username, String password, String otherPassword) {
        if (!isUserNameValid(username)) {
            email_field.setError("Invalid email");//showToast("Invalid email!");
            return false;
            //loginFormState.setValue(new LoginFormState(R.string.invalid_username, null));
        } else if (!isPasswordValid(password)) {
            //showToast("Invalid password must be 5> characters!");
            password_field.setError("Invalid password must be 5> characters!");
            return false;
            //loginFormState.setValue(new LoginFormState(null, R.string.invalid_password));
        }
        else if(!password.equals(otherPassword)){
            //showToast("Password doesn't match!");
            confirm_password_field.setError("Password doesn't match!");
            return false;
        }
        else {
            //loginFormState.setValue(new LoginFormState(true));
            return true;
        }
    }

    private void showRecovery()
    {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case DialogInterface.BUTTON_POSITIVE:
                        //Yes button clicked

                        EditText email_recovery_input = dialog_view.findViewById(R.id.email_recovery_input);

                        FirebaseAuth.getInstance().sendPasswordResetEmail(email_recovery_input.getText().toString())
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            showToast("Email verification sent! Check yout inbox.");
                                        }
                                    }
                                });
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        //No button clicked
                        Log.d("myLogTag","You clicked cancel!");
                        break;
                }
            }
        };

        //LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        dialog_view = LayoutInflater.from(this).inflate(R.layout.recover_dialog, null);
        final AlertDialog alert = builder.setView(dialog_view).setTitle("Enter your email address").setPositiveButton("Ok", dialogClickListener)
                .setNegativeButton("Cancel", dialogClickListener).show();

        dialog_view.findViewById(R.id.email_recovery_input).setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    alert.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                }
            }
        });
    }

    private void showToast(String message){
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
    }

    // A placeholder username validation check
    private boolean isUserNameValid(String username) {
        if (username == null) {
            return false;
        }
        if (username.contains("@")) {
            return Patterns.EMAIL_ADDRESS.matcher(username).matches();
        } else {
            return !username.trim().isEmpty();
        }
    }

    // A placeholder password validation check
    private boolean isPasswordValid(String password) {
        return password != null && password.trim().length() > 5;
    }

    public void toggleLayout(View view)
    {
        if(view.getId()==R.id.register_link){
            login_layout.setVisibility(View.GONE);
            register_layout.setVisibility(View.VISIBLE);
        }
        
        if(view.getId()==R.id.login_link){
            register_layout.setVisibility(View.GONE);
            login_layout.setVisibility(View.VISIBLE);
        }
    }

    public void ShowHidePass(View view){

        if(view.getId()==R.id.show_pass_btn){

            if(password_field.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                ((ImageView)(view)).setImageResource(R.drawable.ic_remove_red_eye_black_24dp);

                //Show Password
                password_field.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            }
            else{
                ((ImageView)(view)).setImageResource(R.drawable.ic_visibility_off_black_24dp);

                //Hide Password
                password_field.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
        }

        if(view.getId()==R.id.show_pass_confirm_btn){

            if(confirm_password_field.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                ((ImageView)(view)).setImageResource(R.drawable.ic_remove_red_eye_black_24dp);

                //Show Password
                confirm_password_field.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            }
            else{
                ((ImageView)(view)).setImageResource(R.drawable.ic_visibility_off_black_24dp);

                //Hide Password
                confirm_password_field.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
        }
    }
}
