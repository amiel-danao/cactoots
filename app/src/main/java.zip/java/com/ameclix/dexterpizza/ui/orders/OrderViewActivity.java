package com.ameclix.dexterpizza.ui.orders;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.ameclix.dexterpizza.MainActivity;
import com.ameclix.dexterpizza.R;
import com.ameclix.dexterpizza.adapters.OrderCartAdapter;
import com.ameclix.dexterpizza.data.model.CartItem;
import com.ameclix.dexterpizza.data.model.Order;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrderViewActivity extends AppCompatActivity {
    public final String TAG = "myLogTag";
    public static Context context;
    private String[] process_button_text = {"Set to Process", "Set to Deliver", "Set to Delivered", "Order Delivered"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_view);

        context = getApplicationContext();

        Intent intent = getIntent();
        final Order selected_order = (Order) intent.getSerializableExtra("SelectedOrder");

        String formatted_order_num = String.format("%04d", selected_order.orderNumber);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setTitle("Order No. : "+formatted_order_num);

        List<CartItem> copy_CartItems = new ArrayList<>();

        ListView order_cart_items_listview = findViewById(R.id.order_cart_items_listview);


        OrderCartAdapter adapter = new OrderCartAdapter(context, copy_CartItems, this);


        int i=0;
        for (CartItem cartItem: selected_order.order_carts) {
            copy_CartItems.add(cartItem);
            Log.d(TAG, "copying " + cartItem.item_name);
            if(i >= selected_order.order_carts.size())
            {
                adapter.notifyDataSetChanged();
            }
        }

        order_cart_items_listview.setAdapter(adapter);

        adapter.notifyDataSetChanged();

        TextView txt_date_ordered = findViewById(R.id.client_date_ordered_edit);
        TextView txt_date_processed = findViewById(R.id.client_last_date_edit);

        txt_date_ordered.setText(selected_order.date_checkout);
        if(selected_order.state == 0)
            txt_date_processed.setText("Pending");
        else
            txt_date_processed.setText(selected_order.last_date_processed);

        if(MainActivity.isAdmin)
        {
            TextView txt_person_name_label = findViewById(R.id.client_name);
            TextView txt_person_phone_label = findViewById(R.id.client_phone);
            TextView txt_person_address_label = findViewById(R.id.client_address);

            txt_person_name_label.setVisibility(View.VISIBLE);
            txt_person_phone_label.setVisibility(View.VISIBLE);
            txt_person_address_label.setVisibility(View.VISIBLE);

            TextView txt_person_name = findViewById(R.id.client_name_edit);
            TextView txt_person_phone = findViewById(R.id.client_phone_edit);
            TextView txt_person_address = findViewById(R.id.client_address_edit);

            txt_person_name.setVisibility(View.VISIBLE);
            txt_person_phone.setVisibility(View.VISIBLE);
            txt_person_address.setVisibility(View.VISIBLE);

            txt_person_name.setText(selected_order.person_name);
            txt_person_phone.setText(selected_order.phone);
            txt_person_address.setText(selected_order.address);

            Button change_process_button = findViewById(R.id.change_process_button);
            change_process_button.setVisibility(View.VISIBLE);
            change_process_button.setText(process_button_text[selected_order.state]);

            //showToast(selected_order.getUid());

            if(selected_order.state < 3) {
                change_process_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        changeProcess(selected_order);
                    }
                });
            }
        }
    }

    private void changeProcess(final Order selected_order) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("orders/" + selected_order.getUid());
        selected_order.setState(selected_order.state+1);

        DateFormat sdf = new SimpleDateFormat("MMMM dd, YYYY hh:mm a");

        Date date = new Date();
        String date_processed = sdf.format(date);

        selected_order.last_date_processed = date_processed;

        myRef.setValue(selected_order).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    OrdersFragment.instance.orderToProcessed = selected_order;
                    finish();
                }
                else
                {
                    showToast(task.getException().getMessage());
                }
            }
        });
    }

    private void showToast(String message){
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onSupportNavigateUp(){
        OrdersFragment.instance.orderToProcessed = null;
        finish();
        return true;
    }
}
