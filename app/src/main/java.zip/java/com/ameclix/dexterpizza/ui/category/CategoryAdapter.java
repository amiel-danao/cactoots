package com.ameclix.dexterpizza.ui.category;

import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;

import com.ameclix.dexterpizza.MainActivity;
import com.ameclix.dexterpizza.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CategoryAdapter extends ArrayAdapter<String> {

    private TextView myCategoryName;
    private View dialog_view;
    private ArrayList<String> theCategoryNames;
    private CategoryFragment theFragment;
    public final String TAG = "myLogTag";

    public CategoryAdapter(Context context, ArrayList<String> categories, CategoryFragment theFragment) {
        super(context, 0, categories);
        this.theCategoryNames = categories;
        this.theFragment = theFragment;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        String category = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(MainActivity.context).inflate(R.layout.category_entry, parent, false);
        }
        // Lookup view for data population
        myCategoryName = (TextView) convertView.findViewById(R.id.category_text);

        // Populate the data into the template view using the data object
        myCategoryName.setText(category);

        // Lookup view for data population
        ImageView btButton = (ImageView) convertView.findViewById(R.id.category_edit);
        // Cache row position inside the button using `setTag`
        btButton.setTag(position);
        // Attach the click event handler

        btButton.setOnClickListener(listener);

        ImageView deleteCategoryButton = (ImageView) convertView.findViewById(R.id.category_delete);
        deleteCategoryButton.setTag(position);

        deleteCategoryButton.setOnClickListener(deletelistener);
        Log.d(TAG, category);
        // Return the completed view to render on screen
        return convertView;
    }

    final View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            int position = (Integer) view.getTag();
            // Access the row position here to get the correct data item
            String selected_category = getItem(position);
            showCategoryRename(position);
        }
    };

    final View.OnClickListener deletelistener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            int position = (Integer) view.getTag();
            // Access the row position here to get the correct data item
            String selected_category = getItem(position);
            showCategoryDelete(position);
        }
    };

    private void showCategoryDelete(final int position) {
        final String selectedCategory = theCategoryNames.get(position);

        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case DialogInterface.BUTTON_POSITIVE:
                        final FirebaseDatabase database = FirebaseDatabase.getInstance();
                        final DatabaseReference myRef = database.getReference("categories/" + selectedCategory);

                        myRef.removeValue();
                        theCategoryNames.remove(position);
                        notifyDataSetChanged();
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        //No button clicked
                        Log.d("myLogTag","You clicked cancel!");
                        break;
                }
            }
        };


        String theMessage = "Are you sure you want to delete the " +  selectedCategory + " category? All items using this category will be set to uncategorized";
        //LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.context);
        //dialog_view = LayoutInflater.from(MainActivity.context).inflate(R.layout.dialog_input, null);
        final AlertDialog alert = builder.setTitle("Confirm Delete").setMessage(theMessage).setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();
    }



    private void showCategoryRename(final int pos)
    {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case DialogInterface.BUTTON_POSITIVE:
                        //Yes button clicked

                        EditText new_category_name = dialog_view.findViewById(R.id.email_login_edit);
                        final String new_category_string = new_category_name.getText().toString();
                        //myCategoryName.setText(new_category_name.getText().toString());


                        //check if new name is different
                        if(new_category_string.equals(theCategoryNames.get(pos)))
                            break;
                        //check if new name doesn't exist yet
                        final FirebaseDatabase database = FirebaseDatabase.getInstance();
                        final DatabaseReference myRef = database.getReference("categories/"+new_category_string);

                        theFragment.showLoading(true);

                        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if(dataSnapshot.exists())
                                {
                                    Toast.makeText(MainActivity.context, "Category name already exists!", Toast.LENGTH_LONG).show();
                                    theFragment.showLoading(false);
                                }
                                else
                                {
                                    Log.d("myLogTag","You rename it to " + new_category_string);
                                    //remove old category
                                    database.getReference("categories/" + theCategoryNames.get(pos)).removeValue();
                                    myRef.setValue(0);
                                    theCategoryNames.set(pos, new_category_string);
                                    notifyDataSetChanged();
                                    theFragment.showLoading(false);
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        //No button clicked
                        Log.d("myLogTag","You clicked cancel!");
                        break;
                }
            }
        };

        //LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.context);
        dialog_view = LayoutInflater.from(MainActivity.context).inflate(R.layout.dialog_input, null);
        final AlertDialog alert = builder.setView(dialog_view).setTitle("Rename category").setPositiveButton("Ok", dialogClickListener)
                .setNegativeButton("Cancel", dialogClickListener).show();

        dialog_view.findViewById(R.id.email_login_edit).setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    alert.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                }
            }
        });
    }
}