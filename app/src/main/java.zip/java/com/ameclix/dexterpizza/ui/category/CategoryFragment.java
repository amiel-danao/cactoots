package com.ameclix.dexterpizza.ui.category;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.ameclix.dexterpizza.MainActivity;
import com.ameclix.dexterpizza.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CategoryFragment extends Fragment {

    public final String TAG = "myLogTag";
    private CategoryViewModel categoryViewModel;
    private FloatingActionButton category_add_button;
    private AlertDialog.Builder builder;
    private View dialog_view;
    private ConstraintLayout loadingProgressBar;
    private LayoutInflater myInflater;
    private ListView category_list_view;
    private CategoryAdapter categoryAdapter;
    private ArrayList<String> arrayOfCategories = new ArrayList<String>();


    public View onCreateView(@NonNull final LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        categoryViewModel =
                ViewModelProviders.of(this).get(CategoryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_categories, container, false);
        final TextView textView = root.findViewById(R.id.text_category);
        categoryViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });

        myInflater = inflater;

        loadingProgressBar = root.findViewById(R.id.loading_constraint);
        builder = new AlertDialog.Builder(MainActivity.context);

        // Construct the data source

        // Create the adapter to convert the array to views

        // Attach the adapter to a ListView
        category_list_view = root.findViewById(R.id.categories_list_view);
        categoryAdapter = new CategoryAdapter(MainActivity.context, arrayOfCategories, this);
        category_list_view.setAdapter(categoryAdapter);




        category_add_button = root.findViewById(R.id.category_add);

        loadCategoriesFromDB();

        category_add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //add new category
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case DialogInterface.BUTTON_POSITIVE:
                                //Yes button clicked
                                Log.d(TAG,"You clicked ok!");
                                EditText category_name = dialog_view.findViewById(R.id.email_login_edit);
                                if(createNewCategory(category_name.getText().toString()))
                                {
                                    showLoading(false);

                                }
                                else
                                {
                                    showLoading(false);
                                    //showToast("New category successfully added!");
                                }
                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                //No button clicked
                                Log.d(TAG,"You clicked cancel!");
                                break;
                        }
                    }
                };

                //LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                dialog_view = inflater.inflate(R.layout.dialog_input, null);
                final AlertDialog alert = builder.setView(dialog_view).setTitle("Create new category").setPositiveButton("Ok", dialogClickListener)
                        .setNegativeButton("Cancel", dialogClickListener).show();

                dialog_view.findViewById(R.id.email_login_edit).setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        if (hasFocus) {
                            alert.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                        }
                    }
                });
            }
        });

        return root;
    }

    private void showToast(String message){
        Toast.makeText(MainActivity.context, message, Toast.LENGTH_LONG).show();
    }

    public void showLoading(boolean show)
    {
        if(show)
            loadingProgressBar.setVisibility(View.VISIBLE);
        else
            loadingProgressBar.setVisibility(View.GONE);
    }



    private void loadCategoriesFromDB()
    {
        showLoading(true);
        arrayOfCategories.clear();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("categories");

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int i =0;


                for (DataSnapshot category: dataSnapshot.getChildren()) {
                    //category_container.addView(createCategoryEntry(category.getKey()));
                    //category_container.invalidate();
                    arrayOfCategories.add(category.getKey());

                    i++;
                    if(i >= category.getChildrenCount())
                    {
                        categoryAdapter.notifyDataSetChanged();
                    }
                }


                showLoading(false);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private boolean createNewCategory(final String new_category_name)
    {
        showLoading(true);

        if(new_category_name.equals("Uncategorized"))
        {
            showToast("Category name already exists!");
            showLoading(false);
            return false;
        }

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference myRef = database.getReference("categories/" + new_category_name);

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    showToast("Category name already exists!");
                }
                else
                {
                    myRef.setValue(0);
                    arrayOfCategories.add(new_category_name);
                    categoryAdapter.notifyDataSetChanged();
//                    category_container.addView(createCategoryEntry(new_category_name));
//                    category_container.invalidate();
                    showLoading(false);
                    showToast("New category successfully added!");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        return false;
    }
}